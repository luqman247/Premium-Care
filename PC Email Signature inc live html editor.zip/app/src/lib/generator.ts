// ============================================================
// PREMIUM CARE SIGNATURE GENERATOR v2.0
// With official Premium Care logo integration
// ============================================================

export interface SignatureConfig {
  name: string;
  titleLine1: string;
  titleLine2: string;
  titleLine3: string;
  company: string;
  phone: string;
  mobile: string;
  email: string;
  website: string;
  address: string;
  postcodeCity: string;
  country: string;
  cvr: string;
  linkedin: string;
  facebook: string;
  instagram: string;
  showEmblem: boolean;
  showSocial: boolean;
}

export const defaultConfig: SignatureConfig = {
  name: 'Luqman Hakim',
  titleLine1: 'Founder',
  titleLine2: 'Chief Executive Officer',
  titleLine3: 'Managing Director',
  company: 'Premium Care ApS',
  phone: '+45 00 00 00 00',
  mobile: '+45 00 00 00 00',
  email: 'luqman.hakim@premiumcare.dk',
  website: 'www.premiumcare.dk',
  address: 'Frederiksberg All\xE9 00',
  postcodeCity: '1820 Frederiksberg C',
  country: 'Danmark',
  cvr: '00 00 00 00',
  linkedin: 'https://linkedin.com/company/premiumcare-aps',
  facebook: 'https://facebook.com/premiumcareaps',
  instagram: 'https://instagram.com/premiumcareaps',
  showEmblem: true,
  showSocial: true,
};

// Brand colour palette
const COLORS = {
  navy: '#061D37',
  navyDeep: '#04152A',
  gold: '#C4A05F',
  goldLight: '#E4C77D',
  goldDark: '#8C6A2D',
  red: '#941715',
  ivory: '#F7F5F0',
  grey: '#39424E',
  muted: '#5A6472',
  greyLight: '#8C949E',
};

// Logo asset paths (served from public/)
const LOGO = {
  emblem72: '/logo/emblem/emblem_72.png',
  emblem64: '/logo/emblem/emblem_64.png',
  emblem48: '/logo/emblem/emblem_48.png',
  emblem44: '/logo/emblem/emblem_44.png',
  emblem32: '/logo/emblem/emblem_32.png',
  emblem80Navy: '/logo/emblem/emblem_80_on_navy.png',
  horizontal180: '/logo/horizontal/horizontal_180.png',
  horizontal160: '/logo/horizontal/horizontal_160.png',
  horizontal120: '/logo/horizontal/horizontal_120.png',
};

// SVG social icons
const svgLinkedIn = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>`;

const svgFacebook = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>`;

const svgInstagram = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>`;

function socialIcons(c: SignatureConfig, strokeColor: string) {
  if (!c.showSocial) return '';
  const items: string[] = [];
  if (c.linkedin) items.push(`<td style="padding-left:10px;"><a href="${c.linkedin}" style="text-decoration:none;display:block;color:${strokeColor};" target="_blank">${svgLinkedIn.replace(/currentColor/g, strokeColor)}</a></td>`);
  if (c.facebook) items.push(`<td style="padding-left:10px;"><a href="${c.facebook}" style="text-decoration:none;display:block;color:${strokeColor};" target="_blank">${svgFacebook.replace(/currentColor/g, strokeColor)}</a></td>`);
  if (c.instagram) items.push(`<td style="padding-left:10px;"><a href="${c.instagram}" style="text-decoration:none;display:block;color:${strokeColor};" target="_blank">${svgInstagram.replace(/currentColor/g, strokeColor)}</a></td>`);
  if (items.length === 0) return '';
  return `<table cellpadding="0" cellspacing="0" border="0"><tr>${items.join('')}</tr></table>`;
}

function labelText(text: string, color: string) {
  return `<span style="font-family:'Jost',sans-serif;font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:${color};">${text}</span>`;
}

function hairlineGradient(start: string, mid: string, end: string) {
  return `linear-gradient(90deg,${start},${mid},${end})`;
}

// ============================================================
// VERSION A — LUXURY EXECUTIVE (with official emblem)
// ============================================================
export function generateLuxury(c: SignatureConfig, dark: boolean): string {
  const p = {
    navy: dark ? COLORS.ivory : COLORS.navy,
    grey: dark ? '#C9CFD8' : COLORS.grey,
    muted: dark ? '#8C949E' : COLORS.muted,
    gold: COLORS.gold,
    labelColor: dark ? COLORS.goldLight : COLORS.goldDark,
    accentColor: dark ? COLORS.goldLight : COLORS.goldDark,
    emblemBg: dark ? COLORS.navyDeep : COLORS.navy,
    emblemBorder: dark ? '1px solid rgba(196,160,95,0.2)' : 'none',
    socialStroke: dark ? COLORS.goldLight : COLORS.goldDark,
    hairlineStart: dark ? 'rgba(228,199,125,0.5)' : 'rgba(196,160,95,0.5)',
    hairlineMid: dark ? 'rgba(228,199,125,0.15)' : 'rgba(196,160,95,0.15)',
    hairlineEnd: 'transparent',
  };

  const titleFull = [c.titleLine1, c.titleLine2, c.titleLine3].filter(Boolean).join(', ');

  const emblemHtml = c.showEmblem
    ? `<td width="80" valign="top" style="padding-right:18px;">
      <table cellpadding="0" cellspacing="0" border="0">
        <tr><td style="padding-bottom:4px;">
          <img src="${LOGO.emblem80Navy}" alt="Premium Care" width="80" height="80" style="display:block;width:80px;height:80px;border-radius:4px;" />
        </td></tr>
        <tr><td style="text-align:center;font-size:7px;color:${p.gold};line-height:1;">&#9670;</td></tr>
      </table>
    </td>`
    : '';

  const socialHtml = socialIcons(c, p.socialStroke);

  return `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:640px;font-family:'Jost','Segoe UI',Verdana,Arial,sans-serif;color:${p.navy};">
  <tr><td style="padding:0;">
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td style="padding-bottom:14px;"><div style="height:1px;background:${hairlineGradient(p.hairlineStart, p.hairlineMid, p.hairlineEnd)};"></div></td></tr></table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
      ${emblemHtml}
      <td valign="top" style="${c.showEmblem ? 'padding-left:4px;' : ''}">
        <table cellpadding="0" cellspacing="0" border="0">
          <tr><td style="font-family:'Cinzel',Georgia,'Times New Roman',serif;font-weight:600;font-size:16px;color:${p.navy};letter-spacing:0.07em;line-height:1.3;">${c.name}</td></tr>
          <tr><td style="font-family:'Cormorant Garamond',Georgia,serif;font-style:italic;font-size:12px;color:${p.muted};padding-top:3px;line-height:1.4;">${titleFull}</td></tr>
          <tr><td style="font-family:'Jost',sans-serif;font-weight:500;font-size:8.5px;letter-spacing:0.22em;text-transform:uppercase;color:${p.labelColor};padding-top:5px;line-height:1;">${c.company}</td></tr>
          <tr><td style="padding-top:10px;"><div style="height:1px;width:140px;background:linear-gradient(90deg,${p.gold},rgba(196,160,95,0));"></div></td></tr>
          <tr><td style="padding-top:10px;">
            <table cellpadding="0" cellspacing="0" border="0"><tr>
              <td style="font-family:'Jost',sans-serif;font-weight:300;font-size:10px;color:${p.grey};line-height:2;padding-right:14px;vertical-align:top;">
                ${c.phone ? `${labelText('Direct', p.labelColor)}&nbsp;&nbsp;<a href="tel:${c.phone.replace(/\s/g, '')}" style="color:${p.grey};text-decoration:none;">${c.phone}</a><br/>` : ''}
                ${c.mobile ? `${labelText('Mobile', p.labelColor)}&nbsp;&nbsp;<a href="tel:${c.mobile.replace(/\s/g, '')}" style="color:${p.grey};text-decoration:none;">${c.mobile}</a>` : ''}
              </td>
              <td style="font-family:'Jost',sans-serif;font-weight:300;font-size:10px;color:${p.grey};line-height:2;vertical-align:top;">
                ${c.email ? `${labelText('Email', p.labelColor)}&nbsp;&nbsp;<a href="mailto:${c.email}" style="color:${p.grey};text-decoration:none;border-bottom:1px solid rgba(196,160,95,0.25);">${c.email}</a><br/>` : ''}
                ${c.website ? `${labelText('Web', p.labelColor)}&nbsp;&nbsp;<a href="https://${c.website.replace(/^https?:\/\//, '')}" style="color:${p.grey};text-decoration:none;">${c.website.replace(/^https?:\/\//, '')}</a>` : ''}
              </td>
            </tr></table>
          </td></tr>
          ${(c.address || c.cvr) ? `<tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:${p.muted};padding-top:4px;line-height:1.6;">${c.address}${c.postcodeCity ? ` &middot; ${c.postcodeCity}` : ''}${c.country ? ` &middot; ${c.country}` : ''}${c.cvr ? `<br/>${labelText('CVR', p.labelColor)}&nbsp;&nbsp;<span style="color:${p.muted};">${c.cvr}</span>` : ''}</td></tr>` : ''}
        </table>
      </td>
    </tr></table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr><td style="padding-top:12px;"><div style="height:1px;background:${hairlineGradient(p.hairlineStart, p.hairlineMid, p.hairlineEnd)};"></div></td></tr>
      <tr><td style="padding-top:6px;">
        <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
          <td style="font-family:'Jost',sans-serif;font-weight:300;font-size:7.5px;letter-spacing:0.22em;text-transform:uppercase;color:${p.accentColor};vertical-align:middle;">Omsorg &middot; Tryghed &middot; Hver Dag</td>
          ${socialHtml ? `<td align="right" style="vertical-align:middle;">${socialHtml}</td>` : ''}
        </tr></table>
      </td></tr>
    </table>
  </td></tr>
</table>`;
}

// ============================================================
// VERSION B — MODERN SCANDINAVIAN (with horizontal logo)
// ============================================================
export function generateModern(c: SignatureConfig, dark: boolean): string {
  const p = {
    navy: dark ? COLORS.ivory : COLORS.navy,
    grey: dark ? '#C9CFD8' : COLORS.grey,
    muted: dark ? '#8C949E' : COLORS.muted,
    gold: COLORS.gold,
    accentColor: dark ? COLORS.goldLight : COLORS.goldDark,
    socialStroke: dark ? COLORS.goldLight : COLORS.goldDark,
    hairlineStart: dark ? 'rgba(228,199,125,0.5)' : 'rgba(196,160,95,0.5)',
    hairlineMid: dark ? 'rgba(228,199,125,0.15)' : 'rgba(196,160,95,0.15)',
  };

  const titleParts = [c.titleLine1, c.titleLine2, c.titleLine3].filter(Boolean);
  const titleStr = titleParts.join(' &nbsp;&middot;&nbsp; ');
  const socialHtml = socialIcons(c, p.socialStroke);

  return `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:520px;font-family:'Jost','Segoe UI',Verdana,Arial,sans-serif;color:${p.navy};">
  <tr><td style="padding:0;">
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
      <td style="padding-bottom:10px;">
        <img src="${LOGO.horizontal120}" alt="Premium Care" width="120" height="106" style="display:block;width:120px;height:106px;" />
      </td>
    </tr></table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td style="font-family:'Cinzel',Georgia,serif;font-weight:600;font-size:15px;color:${p.navy};letter-spacing:0.06em;line-height:1.2;">${c.name}</td></tr>
    <tr><td style="font-family:'Jost',sans-serif;font-weight:400;font-size:9px;letter-spacing:0.16em;text-transform:uppercase;color:${p.muted};padding-top:3px;line-height:1.4;">${titleStr}</td></tr></table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td style="padding-top:12px;padding-bottom:12px;"><div style="height:1px;width:100%;background:linear-gradient(90deg,${p.gold},rgba(196,160,95,0.12));"></div></td></tr></table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
      <td width="50%" valign="top" style="padding-right:12px;">
        <table cellpadding="0" cellspacing="0" border="0">
          ${c.phone ? `<tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:${p.grey};line-height:1.9;"><a href="tel:${c.phone.replace(/\s/g, '')}" style="color:${p.grey};text-decoration:none;">${c.phone}</a></td></tr>` : ''}
          ${c.email ? `<tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:${p.grey};line-height:1.9;"><a href="mailto:${c.email}" style="color:${p.grey};text-decoration:none;">${c.email}</a></td></tr>` : ''}
        </table>
      </td>
      <td width="50%" valign="top" style="padding-left:12px;">
        <table cellpadding="0" cellspacing="0" border="0">
          ${c.website ? `<tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:${p.grey};line-height:1.9;"><a href="https://${c.website.replace(/^https?:\/\//, '')}" style="color:${p.grey};text-decoration:none;">${c.website.replace(/^https?:\/\//, '')}</a></td></tr>` : ''}
          ${c.address ? `<tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9px;color:${p.muted};line-height:1.9;">${c.address}</td></tr>` : ''}
        </table>
      </td>
    </tr></table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr><td style="padding-top:12px;"><div style="height:1px;width:60px;background:${p.gold};opacity:0.5;"></div></td></tr>
      <tr><td style="padding-top:6px;">
        <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
          <td style="font-family:'Jost',sans-serif;font-weight:500;font-size:7.5px;letter-spacing:0.24em;text-transform:uppercase;color:${p.accentColor};vertical-align:middle;">${c.company}</td>
          ${socialHtml ? `<td align="right" style="vertical-align:middle;">${socialHtml}</td>` : ''}
        </tr></table>
      </td></tr>
    </table>
  </td></tr>
</table>`;
}

// ============================================================
// VERSION C — ULTRA MINIMAL (with small emblem accent)
// ============================================================
export function generateMinimal(c: SignatureConfig, dark: boolean): string {
  const p = {
    navy: dark ? COLORS.ivory : COLORS.navy,
    grey: dark ? '#C9CFD8' : COLORS.grey,
    muted: dark ? '#8C949E' : COLORS.muted,
    gold: COLORS.gold,
    accentColor: dark ? COLORS.goldLight : COLORS.goldDark,
  };

  const titleShort = [c.titleLine1, c.titleLine2, c.titleLine3].filter(Boolean).join(' &middot; ');

  return `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:420px;font-family:'Jost','Segoe UI',Verdana,Arial,sans-serif;color:${p.navy};">
  <tr><td style="padding:0 0 2px 0;">
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
      <td style="padding-bottom:10px;">
        <img src="${LOGO.emblem44}" alt="Premium Care" width="44" height="27" style="display:block;width:44px;height:27px;" />
      </td>
    </tr></table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td style="font-family:'Cinzel',Georgia,serif;font-weight:600;font-size:14px;color:${p.navy};letter-spacing:0.08em;line-height:1.25;">${c.name}</td></tr>
    <tr><td style="font-family:'Cormorant Garamond',Georgia,serif;font-style:italic;font-size:11px;color:${p.muted};padding-top:4px;line-height:1.4;">${titleShort}</td></tr></table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td style="padding-top:14px;padding-bottom:12px;"><div style="height:1px;width:48px;background:${p.gold};"></div></td></tr></table>
    <table cellpadding="0" cellspacing="0" border="0">
      ${c.email ? `<tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:${p.grey};line-height:1.8;"><a href="mailto:${c.email}" style="color:${p.grey};text-decoration:none;">${c.email}</a></td></tr>` : ''}
      ${c.website ? `<tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:${p.grey};line-height:1.8;"><a href="https://${c.website.replace(/^https?:\/\//, '')}" style="color:${p.grey};text-decoration:none;">${c.website.replace(/^https?:\/\//, '')}</a></td></tr>` : ''}
    </table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td style="padding-top:16px;">
      <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
        <td style="font-family:'Jost',sans-serif;font-weight:400;font-size:7px;letter-spacing:0.28em;text-transform:uppercase;color:${p.accentColor};vertical-align:middle;">${c.company}</td>
        <td align="right" style="vertical-align:middle;"><span style="font-family:'Jost',sans-serif;font-size:7px;letter-spacing:0.18em;text-transform:uppercase;color:${p.accentColor};">Omsorg &middot; Tryghed &middot; Hver Dag</span></td>
      </tr></table>
    </td></tr></table>
  </td></tr>
</table>`;
}

// ============================================================
// MOBILE VERSION
// ============================================================
export function generateMobile(c: SignatureConfig, dark: boolean): string {
  const p = {
    navy: dark ? COLORS.ivory : COLORS.navy,
    grey: dark ? '#C9CFD8' : COLORS.grey,
    muted: dark ? '#8C949E' : COLORS.muted,
    gold: COLORS.gold,
    accentColor: dark ? COLORS.goldLight : COLORS.goldDark,
  };

  const titleShort = [c.titleLine1, c.titleLine2, c.titleLine3].filter(Boolean).join(' &middot; ');

  return `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:320px;font-family:'Jost','Segoe UI',Verdana,Arial,sans-serif;color:${p.navy};">
  <tr><td style="padding:0;">
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
      <td style="padding-bottom:8px;">
        <img src="${LOGO.emblem32}" alt="Premium Care" width="32" height="20" style="display:block;width:32px;height:20px;" />
      </td>
    </tr></table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td style="font-family:'Cinzel',Georgia,serif;font-weight:600;font-size:13px;color:${p.navy};letter-spacing:0.06em;line-height:1.25;">${c.name}</td></tr>
    <tr><td style="font-family:'Jost',sans-serif;font-weight:400;font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:${p.accentColor};padding-top:3px;line-height:1.3;">${titleShort}</td></tr></table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td style="padding-top:10px;padding-bottom:10px;"><div style="height:1px;width:80px;background:linear-gradient(90deg,${p.gold},rgba(196,160,95,0));"></div></td></tr></table>
    <table cellpadding="0" cellspacing="0" border="0">
      ${c.phone ? `<tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:${p.grey};line-height:1.85;"><a href="tel:${c.phone.replace(/\s/g, '')}" style="color:${p.grey};text-decoration:none;">${c.phone}</a></td></tr>` : ''}
      ${c.email ? `<tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:${p.grey};line-height:1.85;"><a href="mailto:${c.email}" style="color:${p.grey};text-decoration:none;">${c.email}</a></td></tr>` : ''}
      ${c.website ? `<tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:${p.grey};line-height:1.85;"><a href="https://${c.website.replace(/^https?:\/\//, '')}" style="color:${p.grey};text-decoration:none;">${c.website.replace(/^https?:\/\//, '')}</a></td></tr>` : ''}
    </table>
    <table cellpadding="0" cellspacing="0" border="0" width="100%">
      <tr><td style="padding-top:10px;"><div style="height:1px;width:40px;background:${p.gold};opacity:0.5;"></div></td></tr>
      <tr><td style="padding-top:5px;font-family:'Jost',sans-serif;font-weight:400;font-size:7px;letter-spacing:0.22em;text-transform:uppercase;color:${p.accentColor};">${c.company}</td></tr>
    </table>
  </td></tr>
</table>`;
}

// ============================================================
// PLAIN TEXT
// ============================================================
export function generatePlainText(c: SignatureConfig): string {
  const titleFull = [c.titleLine1, c.titleLine2, c.titleLine3].filter(Boolean).join(', ');
  let out = `--\n${c.name}\n${titleFull}\n${c.company}\n\n`;
  if (c.phone) out += `Direct:    ${c.phone}\n`;
  if (c.mobile) out += `Mobile:    ${c.mobile}\n`;
  if (c.email) out += `Email:     ${c.email}\n`;
  if (c.website) out += `Web:       ${c.website}\n\n`;
  if (c.address) out += `${c.address}\n${c.postcodeCity ? c.postcodeCity + '\n' : ''}${c.country}\n`;
  if (c.cvr) out += `CVR: ${c.cvr}\n\n`;
  if (c.linkedin) out += `LinkedIn:  ${c.linkedin.replace('https://', '')}\n\n`;
  out += `${c.company} | Omsorg * Tryghed * Hver Dag`;
  return out;
}
