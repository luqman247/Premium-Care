import { useState, useCallback, useRef, useEffect } from 'react';
import type { SignatureConfig } from '@/lib/generator';
import {
  defaultConfig,
  generateLuxury,
  generateModern,
  generateMinimal,
  generateMobile,
  generatePlainText,
} from '@/lib/generator';

// ============================================================
// INTERACTIVE SIGNATURE BUILDER
// ============================================================

type Version = 'luxury' | 'modern' | 'minimal';
type Mode = 'light' | 'dark';
type ExportFormat = 'html' | 'outlook' | 'gmail' | 'plaintext';

const taglines = [
  'Delivering Premium Care with Compassion.',
  'Exceptional Care. Exceptional Standards.',
  'Professional Care. Personal Commitment.',
  'Where Care Meets Excellence.',
  'Compassion Delivered Professionally.',
  "Denmark's Highest Standard of Care, at Home.",
  'Care Planned with Precision. Delivered with Heart.',
  'The Same Faces. The Agreed Times. The Promised Standard.',
  'Quietly Raising the Standard of Danish Care.',
  'Dignity First. Always.',
  'Your Home. Your Routine. Your Life. We Fit Around You.',
  'Trust Built Through Continuity.',
  'Care Worthy of Denmark\'s Finest Tradition.',
  'Every Visit, Every Day, Every Standard Met.',
  'Unhurried Care for the People Who Built Our World.',
  'Where Danish Values Meet Clinical Excellence.',
  'Not Just Care. A Relationship.',
  'The Standard Others Are Measured Against.',
  'Omsorg. Tryghed. Hver Dag.',
  'Care as It Should Be.',
  'Setting the Benchmark for Private Home Care in Denmark.',
  'For Those Who Will Not Compromise on Care.',
  'Discreet. Dignified. Danish.',
  'Continuity is Not a Feature. It is the Foundation.',
];

function useSignatureBuilder() {
  const [config, setConfig] = useState<SignatureConfig>(defaultConfig);
  const [version, setVersion] = useState<Version>('luxury');
  const [mode, setMode] = useState<Mode>('light');
  const [showExport, setShowExport] = useState(false);
  const [exportFormat, setExportFormat] = useState<ExportFormat>('html');

  const updateField = useCallback(<K extends keyof SignatureConfig>(field: K, value: SignatureConfig[K]) => {
    setConfig(prev => ({ ...prev, [field]: value }));
  }, []);

  const generatedHTML = (() => {
    switch (version) {
      case 'luxury': return generateLuxury(config, mode === 'dark');
      case 'modern': return generateModern(config, mode === 'dark');
      case 'minimal': return generateMinimal(config, mode === 'dark');
    }
  })();

  const mobileHTML = generateMobile(config, mode === 'dark');
  const plainText = generatePlainText(config);

  const outlookHTML = `<html><body style="margin:0;padding:0;font-family:'Jost','Segoe UI',Arial,sans-serif;">${generatedHTML}</body></html>`;
  const gmailHTML = generatedHTML;

  return {
    config, updateField, version, setVersion, mode, setMode,
    generatedHTML, mobileHTML, outlookHTML, gmailHTML, plainText,
    showExport, setShowExport, exportFormat, setExportFormat,
  };
}

// ---- Small components ----
function Label({ children }: { children: React.ReactNode }) {
  return (
    <label style={{
      fontFamily: "'Jost', sans-serif",
      fontWeight: 500,
      fontSize: '9px',
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      color: 'var(--pc-gold-dark)',
      display: 'block',
      marginBottom: '6px',
    }}>
      {children}
    </label>
  );
}

function Input({ value, onChange, placeholder, type = 'text' }: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <input
      type={type}
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      style={{
        fontFamily: "'Jost', sans-serif",
        fontWeight: 400,
        fontSize: '12px',
        color: 'var(--pc-navy)',
        background: '#fff',
        border: '1px solid rgba(6,29,55,0.12)',
        borderRadius: '2px',
        padding: '8px 12px',
        width: '100%',
        outline: 'none',
        transition: 'border-color 0.2s',
      }}
      onFocus={e => e.currentTarget.style.borderColor = 'rgba(196,160,95,0.5)'}
      onBlur={e => e.currentTarget.style.borderColor = 'rgba(6,29,55,0.12)'}
    />
  );
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        background: 'transparent',
        border: 'none',
        cursor: 'pointer',
        padding: '4px 0',
      }}
    >
      <div style={{
        width: '32px',
        height: '18px',
        borderRadius: '9px',
        background: checked ? 'var(--pc-gold)' : 'rgba(6,29,55,0.15)',
        position: 'relative',
        transition: 'background 0.2s',
      }}>
        <div style={{
          width: '14px',
          height: '14px',
          borderRadius: '50%',
          background: '#fff',
          position: 'absolute',
          top: '2px',
          left: checked ? '16px' : '2px',
          transition: 'left 0.2s',
          boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
        }} />
      </div>
      <span style={{
        fontFamily: "'Jost', sans-serif",
        fontSize: '11px',
        fontWeight: 400,
        color: 'var(--pc-grey)',
      }}>{label}</span>
    </button>
  );
}

// ---- Main Page ----
export default function Home() {
  const builder = useSignatureBuilder();
  const { config, updateField, version, setVersion, mode, setMode } = builder;
  const exportRef = useRef<HTMLDivElement>(null);

  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback((text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, []);

  const getExportContent = () => {
    switch (builder.exportFormat) {
      case 'html': return builder.generatedHTML;
      case 'outlook': return builder.outlookHTML;
      case 'gmail': return builder.gmailHTML;
      case 'plaintext': return builder.plainText;
    }
  };

  // Scroll to export when opened
  useEffect(() => {
    if (builder.showExport && exportRef.current) {
      exportRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [builder.showExport]);

  const versions: { key: Version; label: string; desc: string }[] = [
    { key: 'luxury', label: 'Version A — Luxury Executive', desc: 'Horizontal · Emblem · Gold hairlines · Full detail' },
    { key: 'modern', label: 'Version B — Modern Scandinavian', desc: 'Typography-driven · Minimal · Clean' },
    { key: 'minimal', label: 'Version C — Ultra Minimal', desc: 'Museum quality · Publishing aesthetic' },
  ];

  return (
    <div style={{ minHeight: '100vh', background: 'var(--pc-ivory)' }}>

      {/* ===== HEADER ===== */}
      <header style={{
        background: 'var(--pc-navy)',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Gold frame */}
        <div style={{ position: 'absolute', inset: '12px', border: '0.5px solid rgba(196,160,95,0.3)', pointerEvents: 'none', borderRadius: '1px' }} />
        <div style={{ position: 'absolute', top: '8px', left: '50%', transform: 'translateX(-50%)', color: 'var(--pc-gold)', fontSize: '7px', background: 'var(--pc-navy)', padding: '0 10px', letterSpacing: '0.5em' }}>&#9670; &#9670; &#9670;</div>

        <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '3.5rem 2rem 3rem', textAlign: 'center' }}>
          <div className="eyebrow" style={{ color: 'var(--pc-gold)', marginBottom: '1rem', fontSize: '8px' }}>Premium Care ApS &middot; Interactive Builder</div>
          <h1 style={{
            fontFamily: "'Cinzel', serif",
            fontWeight: 600,
            fontSize: 'clamp(16px, 3vw, 26px)',
            color: 'var(--pc-ivory)',
            letterSpacing: '0.18em',
            lineHeight: 1.2,
            marginBottom: '0.75rem',
          }}>
            EXECUTIVE SIGNATURE BUILDER
          </h1>
          <p style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontStyle: 'italic',
            fontSize: '15px',
            color: '#8FA0B8',
            marginBottom: '1.5rem',
          }}>
            Edit in real time. Switch versions. Toggle light & dark. Export production HTML.
          </p>
        </div>
      </header>

      {/* ===== MAIN CONTENT ===== */}
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem', display: 'grid', gridTemplateColumns: '320px 1fr', gap: '2rem' }}>

        {/* ===== LEFT: EDITOR PANEL ===== */}
        <div style={{ position: 'sticky', top: '20px', alignSelf: 'start' }}>
          <div style={{
            background: '#fff',
            border: '1px solid rgba(6,29,55,0.08)',
            overflow: 'hidden',
          }}>
            {/* Panel header */}
            <div style={{ background: 'var(--pc-navy)', padding: '0.7rem 1.25rem' }}>
              <span style={{
                fontFamily: "'Jost', sans-serif",
                fontWeight: 500,
                fontSize: '9.5px',
                letterSpacing: '0.2em',
                textTransform: 'uppercase',
                color: 'var(--pc-gold-light)',
              }}>Editor</span>
            </div>

            <div style={{ padding: '1.25rem', maxHeight: 'calc(100vh - 200px)', overflowY: 'auto' }}>

              {/* Version Switcher */}
              <div style={{ marginBottom: '1.25rem' }}>
                <Label>Signature Version</Label>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {versions.map(v => (
                    <button
                      key={v.key}
                      onClick={() => setVersion(v.key)}
                      style={{
                        textAlign: 'left',
                        padding: '8px 10px',
                        border: version === v.key ? '1px solid rgba(196,160,95,0.5)' : '1px solid rgba(6,29,55,0.1)',
                        background: version === v.key ? 'rgba(196,160,95,0.06)' : 'transparent',
                        cursor: 'pointer',
                        borderRadius: '2px',
                        transition: 'all 0.15s',
                      }}
                    >
                      <div style={{
                        fontFamily: "'Jost', sans-serif",
                        fontWeight: 500,
                        fontSize: '10px',
                        color: version === v.key ? 'var(--pc-navy)' : 'var(--pc-grey)',
                        letterSpacing: '0.06em',
                      }}>{v.label}</div>
                      <div style={{
                        fontFamily: "'Jost', sans-serif",
                        fontWeight: 300,
                        fontSize: '8.5px',
                        color: 'var(--pc-muted)',
                        marginTop: '2px',
                      }}>{v.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Light/Dark Toggle */}
              <div style={{ marginBottom: '1.25rem', paddingBottom: '1.25rem', borderBottom: '1px solid rgba(6,29,55,0.06)' }}>
                <Label>Preview Mode</Label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => setMode('light')}
                    style={{
                      flex: 1,
                      padding: '8px',
                      fontFamily: "'Jost', sans-serif",
                      fontSize: '10px',
                      fontWeight: 500,
                      letterSpacing: '0.14em',
                      textTransform: 'uppercase',
                      border: mode === 'light' ? '1px solid rgba(196,160,95,0.5)' : '1px solid rgba(6,29,55,0.1)',
                      background: mode === 'light' ? 'rgba(196,160,95,0.06)' : '#fff',
                      color: mode === 'light' ? 'var(--pc-navy)' : 'var(--pc-muted)',
                      cursor: 'pointer',
                      borderRadius: '2px',
                    }}
                  >Light</button>
                  <button
                    onClick={() => setMode('dark')}
                    style={{
                      flex: 1,
                      padding: '8px',
                      fontFamily: "'Jost', sans-serif",
                      fontSize: '10px',
                      fontWeight: 500,
                      letterSpacing: '0.14em',
                      textTransform: 'uppercase',
                      border: mode === 'dark' ? '1px solid rgba(196,160,95,0.5)' : '1px solid rgba(6,29,55,0.1)',
                      background: mode === 'dark' ? 'rgba(196,160,95,0.06)' : '#fff',
                      color: mode === 'dark' ? 'var(--pc-navy)' : 'var(--pc-muted)',
                      cursor: 'pointer',
                      borderRadius: '2px',
                    }}
                  >Dark</button>
                </div>
              </div>

              {/* Name & Title */}
              <div style={{ marginBottom: '1rem' }}>
                <Label>Full Name</Label>
                <Input value={config.name} onChange={v => updateField('name', v)} placeholder="Luqman Hakim" />
              </div>

              <div style={{ marginBottom: '1rem' }}>
                <Label>Title Line 1</Label>
                <Input value={config.titleLine1} onChange={v => updateField('titleLine1', v)} placeholder="Founder" />
              </div>
              <div style={{ marginBottom: '1rem' }}>
                <Label>Title Line 2</Label>
                <Input value={config.titleLine2} onChange={v => updateField('titleLine2', v)} placeholder="Chief Executive Officer" />
              </div>
              <div style={{ marginBottom: '1rem' }}>
                <Label>Title Line 3</Label>
                <Input value={config.titleLine3} onChange={v => updateField('titleLine3', v)} placeholder="Managing Director" />
              </div>

              <div style={{ marginBottom: '1rem' }}>
                <Label>Company</Label>
                <Input value={config.company} onChange={v => updateField('company', v)} placeholder="Premium Care ApS" />
              </div>

              {/* Contact */}
              <div style={{ margin: '1.25rem 0', paddingTop: '1.25rem', borderTop: '1px solid rgba(6,29,55,0.06)' }}>
                <div className="eyebrow" style={{ fontSize: '7px', marginBottom: '0.75rem' }}>Contact Details</div>
                <div style={{ marginBottom: '0.75rem' }}>
                  <Label>Phone</Label>
                  <Input value={config.phone} onChange={v => updateField('phone', v)} placeholder="+45 00 00 00 00" />
                </div>
                <div style={{ marginBottom: '0.75rem' }}>
                  <Label>Mobile</Label>
                  <Input value={config.mobile} onChange={v => updateField('mobile', v)} placeholder="+45 00 00 00 00" />
                </div>
                <div style={{ marginBottom: '0.75rem' }}>
                  <Label>Email</Label>
                  <Input value={config.email} onChange={v => updateField('email', v)} placeholder="luqman.hakim@premiumcare.dk" />
                </div>
                <div style={{ marginBottom: '0.75rem' }}>
                  <Label>Website</Label>
                  <Input value={config.website} onChange={v => updateField('website', v)} placeholder="www.premiumcare.dk" />
                </div>
              </div>

              {/* Address */}
              <div style={{ marginBottom: '1rem' }}>
                <Label>Address</Label>
                <Input value={config.address} onChange={v => updateField('address', v)} placeholder="Frederiksberg Allé 00" />
              </div>
              <div style={{ marginBottom: '1rem' }}>
                <Label>Postcode & City</Label>
                <Input value={config.postcodeCity} onChange={v => updateField('postcodeCity', v)} placeholder="1820 Frederiksberg C" />
              </div>
              <div style={{ marginBottom: '1rem' }}>
                <Label>Country</Label>
                <Input value={config.country} onChange={v => updateField('country', v)} placeholder="Danmark" />
              </div>
              <div style={{ marginBottom: '1rem' }}>
                <Label>CVR Number</Label>
                <Input value={config.cvr} onChange={v => updateField('cvr', v)} placeholder="00 00 00 00" />
              </div>

              {/* Social */}
              <div style={{ margin: '1.25rem 0', paddingTop: '1.25rem', borderTop: '1px solid rgba(6,29,55,0.06)' }}>
                <div className="eyebrow" style={{ fontSize: '7px', marginBottom: '0.75rem' }}>Social Links</div>
                <div style={{ marginBottom: '0.75rem' }}>
                  <Label>LinkedIn</Label>
                  <Input value={config.linkedin} onChange={v => updateField('linkedin', v)} placeholder="https://linkedin.com/company/..." />
                </div>
                <div style={{ marginBottom: '0.75rem' }}>
                  <Label>Facebook</Label>
                  <Input value={config.facebook} onChange={v => updateField('facebook', v)} placeholder="https://facebook.com/..." />
                </div>
                <div style={{ marginBottom: '0.75rem' }}>
                  <Label>Instagram</Label>
                  <Input value={config.instagram} onChange={v => updateField('instagram', v)} placeholder="https://instagram.com/..." />
                </div>
              </div>

              {/* Options */}
              <div style={{ paddingTop: '1rem', borderTop: '1px solid rgba(6,29,55,0.06)' }}>
                <Toggle checked={config.showEmblem} onChange={v => updateField('showEmblem', v)} label="Show emblem (Version A)" />
                <Toggle checked={config.showSocial} onChange={v => updateField('showSocial', v)} label="Show social icons" />
              </div>
            </div>
          </div>
        </div>

        {/* ===== RIGHT: PREVIEW PANEL ===== */}
        <div>
          {/* Version tabs */}
          <div style={{
            display: 'flex',
            gap: '2px',
            marginBottom: '1.5rem',
            background: 'rgba(6,29,55,0.04)',
            padding: '3px',
            borderRadius: '3px',
          }}>
            {versions.map(v => (
              <button
                key={v.key}
                onClick={() => setVersion(v.key)}
                style={{
                  flex: 1,
                  padding: '10px',
                  fontFamily: "'Jost', sans-serif",
                  fontWeight: version === v.key ? 500 : 400,
                  fontSize: '10px',
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                  border: 'none',
                  background: version === v.key ? '#fff' : 'transparent',
                  color: version === v.key ? 'var(--pc-navy)' : 'var(--pc-muted)',
                  cursor: 'pointer',
                  borderRadius: '2px',
                  boxShadow: version === v.key ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
                  transition: 'all 0.15s',
                }}
              >
                {v.key === 'luxury' ? 'A — Luxury' : v.key === 'modern' ? 'B — Modern' : 'C — Ultra Minimal'}
              </button>
            ))}
          </div>

          {/* Preview Card */}
          <div style={{
            background: mode === 'dark' ? 'var(--pc-navy-deep)' : '#fff',
            border: mode === 'dark' ? '1px solid rgba(196,160,95,0.15)' : '1px solid rgba(6,29,55,0.08)',
            overflow: 'hidden',
            marginBottom: '1.5rem',
          }}>
            {/* Preview header */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '0.6rem 1.25rem',
              borderBottom: mode === 'dark' ? '1px solid rgba(196,160,95,0.1)' : '1px solid rgba(6,29,55,0.06)',
            }}>
              <span style={{
                fontFamily: "'Jost', sans-serif",
                fontWeight: 500,
                fontSize: '9px',
                letterSpacing: '0.2em',
                textTransform: 'uppercase',
                color: mode === 'dark' ? 'var(--pc-gold-light)' : 'var(--pc-gold-dark)',
              }}>
                Live Preview &middot; {mode === 'light' ? 'Light Mode' : 'Dark Mode'}
              </span>
              <span style={{
                fontFamily: "'Jost', sans-serif",
                fontSize: '8px',
                letterSpacing: '0.12em',
                color: mode === 'dark' ? '#6B7B8F' : 'var(--pc-muted)',
                textTransform: 'uppercase',
              }}>
                {version === 'luxury' ? '640px max' : version === 'modern' ? '520px max' : '420px max'}
              </span>
            </div>

            {/* Live signature render */}
            <div style={{
              padding: '2.5rem',
              minHeight: '200px',
              background: mode === 'dark' ? 'var(--pc-navy-deep)' : '#fff',
            }}>
              <div dangerouslySetInnerHTML={{ __html: builder.generatedHTML }} />
            </div>
          </div>

          {/* Mobile preview */}
          <div style={{ marginBottom: '1.5rem' }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              marginBottom: '0.75rem',
            }}>
              <span style={{
                fontFamily: "'Cinzel', serif",
                fontWeight: 600,
                fontSize: '12px',
                color: 'var(--pc-navy)',
                letterSpacing: '0.04em',
              }}>Mobile Preview</span>
              <div style={{ flex: 1, height: '1px', background: 'linear-gradient(90deg, rgba(196,160,95,0.3), transparent)' }} />
              <span style={{
                fontFamily: "'Jost', sans-serif",
                fontSize: '8px',
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
                color: 'var(--pc-muted)',
              }}>320px</span>
            </div>
            <div style={{
              background: mode === 'dark' ? 'var(--pc-navy-deep)' : '#fff',
              border: mode === 'dark' ? '1px solid rgba(196,160,95,0.15)' : '1px solid rgba(6,29,55,0.08)',
              padding: '2rem',
              maxWidth: '360px',
            }}>
              <div dangerouslySetInnerHTML={{ __html: builder.mobileHTML }} />
            </div>
          </div>

          {/* Tagline selector */}
          <div style={{ marginBottom: '1.5rem' }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              marginBottom: '0.75rem',
            }}>
              <span style={{
                fontFamily: "'Cinzel', serif",
                fontWeight: 600,
                fontSize: '12px',
                color: 'var(--pc-navy)',
                letterSpacing: '0.04em',
              }}>Executive Taglines</span>
              <div style={{ flex: 1, height: '1px', background: 'linear-gradient(90deg, rgba(196,160,95,0.3), transparent)' }} />
            </div>
            <div style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '6px',
            }}>
              {taglines.map((t, i) => (
                <button
                  key={i}
                  onClick={() => handleCopy(t)}
                  title="Click to copy"
                  style={{
                    fontFamily: "'Cormorant Garamond', serif",
                    fontStyle: 'italic',
                    fontSize: '12px',
                    color: 'var(--pc-grey)',
                    background: '#fff',
                    border: '1px solid rgba(6,29,55,0.08)',
                    padding: '6px 12px',
                    cursor: 'pointer',
                    borderRadius: '2px',
                    transition: 'all 0.15s',
                  }}
                  onMouseEnter={e => {
                    e.currentTarget.style.borderColor = 'rgba(196,160,95,0.4)';
                    e.currentTarget.style.background = 'rgba(196,160,95,0.04)';
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.borderColor = 'rgba(6,29,55,0.08)';
                    e.currentTarget.style.background = '#fff';
                  }}
                >
                  {t}
                </button>
              ))}
            </div>
            {copied && (
              <div style={{
                marginTop: '8px',
                fontFamily: "'Jost', sans-serif",
                fontSize: '10px',
                color: '#1F6B45',
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
              }}>
                Tagline copied to clipboard
              </div>
            )}
          </div>

          {/* Export Button */}
          <button
            onClick={() => builder.setShowExport(!builder.showExport)}
            style={{
              width: '100%',
              padding: '14px',
              fontFamily: "'Jost', sans-serif",
              fontWeight: 500,
              fontSize: '10px',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: '#fff',
              background: 'var(--pc-navy)',
              border: 'none',
              cursor: 'pointer',
              borderRadius: '2px',
              transition: 'background 0.2s',
              marginBottom: '1.5rem',
            }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--pc-navy-deep)'}
            onMouseLeave={e => e.currentTarget.style.background = 'var(--pc-navy)'}
          >
            {builder.showExport ? 'Hide Export Panel' : 'Export Production HTML'}
          </button>

          {/* Export Panel */}
          {builder.showExport && (
            <div ref={exportRef} style={{
              background: '#fff',
              border: '1px solid rgba(6,29,55,0.1)',
              overflow: 'hidden',
            }}>
              {/* Export header */}
              <div style={{ background: 'var(--pc-navy)', padding: '0.6rem 1.25rem' }}>
                <span style={{
                  fontFamily: "'Jost', sans-serif",
                  fontWeight: 500,
                  fontSize: '9.5px',
                  letterSpacing: '0.2em',
                  textTransform: 'uppercase',
                  color: 'var(--pc-gold-light)',
                }}>Export Code</span>
              </div>

              {/* Format tabs */}
              <div style={{
                display: 'flex',
                gap: '1px',
                background: 'rgba(6,29,55,0.04)',
                padding: '3px',
              }}>
                {[
                  { key: 'html' as ExportFormat, label: 'HTML' },
                  { key: 'outlook' as ExportFormat, label: 'Outlook' },
                  { key: 'gmail' as ExportFormat, label: 'Gmail' },
                  { key: 'plaintext' as ExportFormat, label: 'Plain Text' },
                ].map(f => (
                  <button
                    key={f.key}
                    onClick={() => builder.setExportFormat(f.key)}
                    style={{
                      flex: 1,
                      padding: '8px',
                      fontFamily: "'Jost', sans-serif",
                      fontWeight: builder.exportFormat === f.key ? 500 : 400,
                      fontSize: '9px',
                      letterSpacing: '0.12em',
                      textTransform: 'uppercase',
                      border: 'none',
                      background: builder.exportFormat === f.key ? '#fff' : 'transparent',
                      color: builder.exportFormat === f.key ? 'var(--pc-navy)' : 'var(--pc-muted)',
                      cursor: 'pointer',
                      borderRadius: '2px',
                      boxShadow: builder.exportFormat === f.key ? '0 1px 2px rgba(0,0,0,0.06)' : 'none',
                    }}
                  >{f.label}</button>
                ))}
              </div>

              {/* Code block */}
              <div style={{ padding: '1.25rem' }}>
                <div style={{
                  background: 'var(--pc-navy-deep)',
                  padding: '1.25rem',
                  borderRadius: '2px',
                  overflow: 'hidden',
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                    <span style={{
                      fontFamily: "'Jost', sans-serif",
                      fontSize: '8px',
                      letterSpacing: '0.18em',
                      textTransform: 'uppercase',
                      color: 'var(--pc-gold-dark)',
                    }}>
                      {builder.exportFormat === 'html' && 'Inline CSS HTML'}
                      {builder.exportFormat === 'outlook' && 'Outlook-Compatible HTML'}
                      {builder.exportFormat === 'gmail' && 'Gmail-Compatible HTML'}
                      {builder.exportFormat === 'plaintext' && 'Plain Text Fallback'}
                    </span>
                    <button
                      onClick={() => handleCopy(getExportContent())}
                      style={{
                        fontFamily: "'Jost', sans-serif",
                        fontSize: '9px',
                        fontWeight: 500,
                        letterSpacing: '0.16em',
                        textTransform: 'uppercase',
                        color: 'var(--pc-gold)',
                        background: 'transparent',
                        border: '1px solid rgba(196,160,95,0.35)',
                        padding: '4px 14px',
                        cursor: 'pointer',
                        borderRadius: '2px',
                      }}
                    >
                      {copied ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <pre style={{
                    fontFamily: "'Courier New', monospace",
                    fontSize: '10px',
                    lineHeight: 1.65,
                    color: '#A8B4C4',
                    whiteSpace: 'pre-wrap',
                    wordBreak: 'break-all',
                    maxHeight: '400px',
                    overflowY: 'auto',
                    margin: 0,
                  }}>{getExportContent()}</pre>
                </div>
              </div>
            </div>
          )}

          {/* Footer */}
          <div style={{
            marginTop: '3rem',
            paddingTop: '1.5rem',
            borderTop: '1px solid rgba(6,29,55,0.06)',
            textAlign: 'center',
          }}>
            <div style={{ color: 'var(--pc-gold)', fontSize: '7px', letterSpacing: '0.6em', marginBottom: '0.75rem' }}>&#9670; &#9670; &#9670;</div>
            <div style={{
              fontFamily: "'Jost', sans-serif",
              fontSize: '8px',
              letterSpacing: '0.28em',
              textTransform: 'uppercase',
              color: 'var(--pc-muted)',
            }}>
              Omsorg &middot; Tryghed &middot; Hver Dag &nbsp;&middot;&nbsp; Premium Care ApS
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
