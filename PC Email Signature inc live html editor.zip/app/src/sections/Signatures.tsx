import SignatureCard from '@/components/SignatureCard';
import {
  signatureA_HTML,
  signatureA_dark_HTML,
  signatureB_HTML,
  signatureB_dark_HTML,
  signatureC_HTML,
  signatureC_dark_HTML,
  signatureMobile_HTML,
  signaturePlainText,
} from '@/data/signatures';
import CodeBlock from '@/components/CodeBlock';

const signatures = [
  {
    title: 'Version A \u2014 Luxury Executive',
    tag: 'Horizontal \u00b7 Premium \u00b7 Full Detail',
    lightHtml: signatureA_HTML,
    darkHtml: signatureA_dark_HTML,
    description:
      'The flagship signature. Generous whitespace, horizontal layout with emblem anchoring the left column, gold hairline dividers, labeled contact fields in a two-column grid, and the device line closure. This is the gold standard.',
    rationale: [
      '72px emblem on Midnight Navy grounds the composition with brand authority',
      'Diamond ornament below emblem references the brand\'s sole decorative element',
      'Cormorant Garamond italic for title adds editorial warmth and human personality',
      'Gold Dark labels (\u201cDirect\u201d, \u201cMobile\u201d, \u201cEmail\u201d, \u201cWeb\u201d) create scannable hierarchy without visual noise',
      'Two-column contact grid saves vertical space while maintaining readability',
      'Social icons at 14px with 1.5px stroke match Jost\'s geometric construction',
      'Bottom device line closure with social links provides brand reinforcement',
      '640px max-width ensures compatibility with all email clients',
    ],
  },
  {
    title: 'Version B \u2014 Modern Scandinavian',
    tag: 'Apple & B&O Inspired \u00b7 Clean \u00b7 Minimal',
    lightHtml: signatureB_HTML,
    darkHtml: signatureB_dark_HTML,
    description:
      'Inspired by the restraint of Apple and Bang & Olufsen. No emblem. No icons in the contact block. Pure typography hierarchy with a single full-width gold hairline. The name does all the work.',
    rationale: [
      'No visual mark \u2014 the typography IS the identity, as in Bang & Olufsen communications',
      'Single full-width gradient hairline replaces all other decoration',
      'Title set in tracked uppercase Jost (not italic) for clinical precision',
      'Two-column contact layout with subtle vertical rhythm',
      '60px gold accent line at bottom acts as a full-stop punctuation mark',
      'Company name in tracked uppercase provides institutional grounding',
      'Social icons reduced to 13px and pushed to far right \u2014 present but subordinate',
      'Maximum restraint: every element justifies its existence',
    ],
  },
  {
    title: 'Version C \u2014 Ultra Minimal',
    tag: 'Museum Quality \u00b7 Typography Only \u00b7 Publishing',
    lightHtml: signatureC_HTML,
    darkHtml: signatureC_dark_HTML,
    description:
      'Almost entirely typography. A luxury publishing aesthetic inspired by Kinfolk, The Gentlewoman, and T Magazine. Only essential information. Museum-quality spacing. The 48px solid gold rule is the only decorative element.',
    rationale: [
      'No emblem, no icons, no social links \u2014 radical minimalism signals supreme confidence',
      'Cinzel at 14px with +0.08em tracking \u2014 the name as sculpture',
      'Cormorant Garamond italic for role adds sophisticated editorial contrast',
      '48px solid gold rule (not gradient) \u2014 a deliberate, confident punctuation',
      'Only two contact lines: email and website \u2014 everything else is superfluous',
      'Company name and device line in 7px tracked uppercase at the baseline',
      '420px max-width forces compact, intentional composition',
      'The spacing between elements is as important as the elements themselves',
    ],
  },
];

export default function Signatures() {
  return (
    <section id="signatures" style={{ padding: '5rem 2rem 3rem', maxWidth: '900px', margin: '0 auto' }}>
      <div className="eyebrow" style={{ fontSize: '8px', marginBottom: '0.75rem' }}>
        Signature Collection
      </div>
      <h2 className="section-title">Three Versions. One Standard.</h2>
      <p className="section-sub">
        Each version maintains complete brand consistency while offering a different expression of authority.
      </p>
      <div className="gold-hairline" style={{ maxWidth: '400px', margin: '1.5rem 0 2.5rem' }} />

      {signatures.map((sig) => (
        <SignatureCard key={sig.title} {...sig} />
      ))}

      {/* Mobile Version */}
      <div style={{ marginTop: '3rem' }}>
        <div className="sig-card">
          <div className="sig-card-header">
            <h3>Mobile Version &mdash; Responsive Compact</h3>
            <span className="tag">320px &middot; Stacked &middot; All Clients</span>
          </div>
          <div className="sig-preview-light" style={{ minHeight: '140px' }}>
            <div dangerouslySetInnerHTML={{ __html: signatureMobile_HTML }} />
          </div>
          <CodeBlock code={signatureMobile_HTML} id="sig-mobile" label="Mobile HTML (320px max-width)" />
        </div>
      </div>

      {/* Plain Text */}
      <div style={{ marginTop: '2rem' }}>
        <div className="sig-card">
          <div className="sig-card-header">
            <h3>Plain Text Version</h3>
            <span className="tag">Universal Fallback &middot; No HTML</span>
          </div>
          <div
            style={{
              padding: '1.5rem 2rem',
              background: '#fff',
              fontFamily: "'Courier New', monospace",
              fontSize: '10.5px',
              lineHeight: 1.7,
              color: 'var(--pc-grey)',
              whiteSpace: 'pre-wrap',
            }}
          >
            {signaturePlainText}
          </div>
          <CodeBlock code={signaturePlainText} id="sig-plain" label="Plain Text" />
        </div>
      </div>
    </section>
  );
}
