const principles = [
  {
    title: 'Typography as Authority',
    body: 'The name \u201C\u200ALuqman Hakim\u200A\u201D is set in Cinzel at 14\u201317px with +0.05 to +0.08em letter-spacing. Cinzel is an inscriptional Roman capital typeface \u2014 it carries the same gravitas as a name carved in stone. This is not a font choice; it is a statement of permanence. The fallback stack (Georgia \u2192 Times New Roman) ensures dignity even where webfonts fail.',
  },
  {
    title: 'The Gold Hairline as Signature',
    body: 'Every version uses a 1px gradient hairline in Regal Gold (#C4A05F) that fades to transparent. This is the brand\'s most distinctive graphic device. At 0.4pt in print and 1px on screen, it is barely perceptible \u2014 yet its absence would be immediately felt. The hairline separates without dividing; it marks hierarchy without creating boxes.',
  },
  {
    title: 'Cormorant Garamond for Human Warmth',
    body: 'The title \u201CFounder, Chief Executive Officer & Managing Director\u201D is set in Cormorant Garamond Italic in Versions A and C. This serif italic introduces editorial warmth into an otherwise geometric system. It signals: this person has taste. The italic also creates visual contrast against the upright Jost and Cinzel letterforms, adding compositional interest without decoration.',
  },
  {
    title: 'Labelled Contact Information',
    body: 'In Version A, each contact method is prefixed with a label \u2014 \u201cDirect\u201D, \u201cMobile\u201D, \u201cEmail\u201D, \u201cWeb\u201D \u2014 set in Gold Dark (#8C6A2D) at 8px with +0.14em tracking. These labels serve three purposes: they create scannable hierarchy, they occupy space that would otherwise feel empty, and they add a layer of systematic precision that signals organisational excellence.',
  },
  {
    title: 'The Device Line Closure',
    body: 'Versions A and B close with \u201COmsorg \u00b7 Tryghed \u00b7 Hver Dag\u201D in letter-spaced uppercase at 7\u20137.5px. This is not decoration \u2014 it is a contract. Every email carries the three brand promises: Care, Security, Every Day. The interpunct (\u00b7) is always set in gold with hairspaces either side, never replaced by a slash or hyphen.',
  },
  {
    title: 'Emblem Placement and Clear Space',
    body: 'Version A places the 72\u00d772px emblem on a Midnight Navy (#061D37) rounded square. The navy grounds the emblem; the rounded corners (3px radius) soften the geometry. Clear space of 8px minimum is maintained on all sides. Below the emblem, a single diamond ornament (&#9670;) at 7px in Regal Gold closes the vertical axis. This is the only permitted use of the diamond as ornament in the signature system.',
  },
  {
    title: 'Dark Mode Optimisation',
    body: 'Dark mode versions invert the palette while maintaining brand integrity: ivory text on navy-deep backgrounds, Gold Light (#E4C77D) replacing Gold Dark for labels, and muted gold (#C4A05F) for icons. All hairlines shift to semi-transparent gold gradients. The emblem background darkens to Navy Deep (#04152A) with a subtle gold border stroke. No element disappears; all maintain 4.6:1 minimum contrast ratio (WCAG AA).',
  },
  {
    title: 'Scandinavian Restraint',
    body: 'The design philosophy draws from Bang & Olufsen\'s product photography (generous space, single hero element), Apple\'s systematic consistency (every pixel earned), and Aesop\'s editorial confidence (typography as the primary visual event). Nothing is added for decoration. Every element either communicates information or reinforces brand hierarchy. The result feels inevitable, not designed.',
  },
  {
    title: 'Email Client Compatibility',
    body: 'All HTML uses table-based layout with inline CSS only. No external stylesheets, no JavaScript, no frameworks, no dependencies. Maximum width is 640px (Version A), 520px (Version B), and 420px (Version C) \u2014 well within the 600px safe zone for Outlook. SVG icons are inline, not referenced externally. All images use HTTPS URLs. The code works immediately in Outlook 2016+, Gmail, Apple Mail, iOS Mail, and Office 365.',
  },
  {
    title: 'Accessibility by Design',
    body: 'All text meets WCAG 2.2 AA: Navy (#061D37) on Ivory (#F7F5F0) produces 15.9:1 contrast (AAA). Gold Dark (#8C6A2D) on Ivory produces 4.6:1 (AA for text \u22657pt). Minimum body text is 9.5px. All images carry alt text (\u201cPremium Care\u201D). Semantic HTML tables maintain reading order for screen readers. Touch targets for social icons are 14\u00d714px with 10px gaps, exceeding 44px when padded.',
  },
];

export default function Rationale() {
  return (
    <section id="rationale" style={{ padding: '4rem 2rem', maxWidth: '900px', margin: '0 auto' }}>
      <div className="eyebrow" style={{ fontSize: '8px', marginBottom: '0.75rem' }}>
        Design Rationale
      </div>
      <h2 className="section-title">Every Decision, Explained</h2>
      <p className="section-sub">
        Ten principles that govern every pixel of the executive signature system.
      </p>
      <div className="gold-hairline" style={{ maxWidth: '400px', margin: '1.5rem 0 2.5rem' }} />

      <div
        style={{
          borderLeft: '1px solid rgba(196,160,95,0.25)',
          paddingLeft: '2rem',
        }}
      >
        {principles.map((p, i) => (
          <div
            key={i}
            style={{
              marginBottom: '2.5rem',
              position: 'relative',
            }}
          >
            {/* Diamond marker */}
            <span
              style={{
                position: 'absolute',
                left: '-2.35rem',
                top: '2px',
                color: 'var(--pc-gold)',
                fontSize: '8px',
              }}
            >
              &#9670;
            </span>

            <h4
              style={{
                fontFamily: "'Cinzel', serif",
                fontWeight: 600,
                fontSize: '13px',
                color: 'var(--pc-navy)',
                letterSpacing: '0.04em',
                marginBottom: '0.6rem',
              }}
            >
              {p.title}
            </h4>
            <p
              style={{
                fontFamily: "'Jost', sans-serif",
                fontWeight: 300,
                fontSize: '11px',
                color: 'var(--pc-grey)',
                lineHeight: 1.75,
                maxWidth: '640px',
              }}
            >
              {p.body}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
