export default function Footer() {
  return (
    <footer
      style={{
        background: 'var(--pc-navy-deep)',
        padding: '4rem 2rem 3rem',
        textAlign: 'center',
        marginTop: '4rem',
        position: 'relative',
      }}
    >
      {/* Top hairline */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: '50%',
          transform: 'translateX(-50%)',
          width: '60px',
          height: '1px',
          background: 'linear-gradient(90deg, transparent, var(--pc-gold), transparent)',
        }}
      />

      {/* Diamonds */}
      <div
        style={{
          color: 'var(--pc-gold)',
          fontSize: '8px',
          letterSpacing: '0.8em',
          marginBottom: '1.5rem',
        }}
      >
        &#9670; &#9670; &#9670;
      </div>

      {/* Device line */}
      <p
        style={{
          fontFamily: "'Jost', sans-serif",
          fontWeight: 300,
          fontSize: '8px',
          letterSpacing: '0.32em',
          textTransform: 'uppercase',
          color: 'var(--pc-gold-dark)',
          marginBottom: '1.25rem',
        }}
      >
        Omsorg &middot; Tryghed &middot; Hver Dag
      </p>

      {/* Meta */}
      <p
        style={{
          fontFamily: "'Jost', sans-serif",
          fontSize: '8px',
          letterSpacing: '0.22em',
          textTransform: 'uppercase',
          color: '#3A4C63',
          lineHeight: 2,
        }}
      >
        Premium Care ApS &middot; Email Identity System v1.0
      </p>
      <p
        style={{
          fontFamily: "'Jost', sans-serif",
          fontSize: '8px',
          letterSpacing: '0.18em',
          textTransform: 'uppercase',
          color: '#2A3440',
        }}
      >
        Governed by the Brand Identity Manual &middot; Confidential
      </p>

      {/* Bottom diamond */}
      <div
        style={{
          marginTop: '2rem',
          color: 'var(--pc-gold)',
          fontSize: '7px',
          opacity: 0.4,
        }}
      >
        &#9670;
      </div>
    </footer>
  );
}
