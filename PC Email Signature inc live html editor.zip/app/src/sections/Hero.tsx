export default function Hero() {
  return (
    <header
      className="relative overflow-hidden"
      style={{
        background: 'var(--pc-navy)',
        padding: '7rem 2rem 5rem',
        textAlign: 'center',
      }}
    >
      {/* Gold hairline frame */}
      <div
        style={{
          position: 'absolute',
          inset: '14px',
          border: '0.5px solid rgba(196,160,95,0.3)',
          pointerEvents: 'none',
        }}
      />
      {/* Diamond at top center */}
      <div
        style={{
          position: 'absolute',
          top: '8px',
          left: '50%',
          transform: 'translateX(-50%)',
          color: 'var(--pc-gold)',
          fontSize: '7px',
          background: 'var(--pc-navy)',
          padding: '0 8px',
          letterSpacing: '0.4em',
        }}
      >
        &#9670; &#9670; &#9670;
      </div>

      {/* Eyebrow */}
      <div
        className="eyebrow"
        style={{
          color: 'var(--pc-gold)',
          marginBottom: '1.5rem',
          fontSize: '8px',
          letterSpacing: '0.36em',
        }}
      >
        Premium Care ApS &middot; K&oslash;benhavn
      </div>

      {/* Main title */}
      <h1
        style={{
          fontFamily: "'Cinzel', Georgia, serif",
          fontWeight: 600,
          fontSize: 'clamp(17px, 3.2vw, 30px)',
          color: 'var(--pc-ivory)',
          letterSpacing: '0.2em',
          lineHeight: 1.25,
          marginBottom: '0.75rem',
        }}
      >
        EXECUTIVE EMAIL SIGNATURE
      </h1>

      {/* Subtitle */}
      <p
        style={{
          fontFamily: "'Cormorant Garamond', Georgia, serif",
          fontStyle: 'italic',
          fontSize: 'clamp(13px, 1.8vw, 17px)',
          color: '#A8B4C4',
          marginBottom: '2.5rem',
          lineHeight: 1.5,
        }}
      >
        For the Founder, Chief Executive Officer & Managing Director
      </p>

      {/* Diamond separator */}
      <div
        style={{
          color: 'var(--pc-gold)',
          fontSize: '7px',
          letterSpacing: '0.8em',
          marginBottom: '1.5rem',
        }}
      >
        &#9670; &#9670; &#9670;
      </div>

      {/* Meta */}
      <div
        style={{
          fontFamily: "'Jost', sans-serif",
          fontSize: '8.5px',
          letterSpacing: '0.28em',
          textTransform: 'uppercase' as const,
          color: '#6B7B8F',
        }}
      >
        Luqman Hakim &nbsp;&middot;&nbsp; Email Identity System v1.0
      </div>

      {/* Bottom diamond */}
      <div
        style={{
          position: 'absolute',
          bottom: '8px',
          left: '50%',
          transform: 'translateX(-50%)',
          color: 'var(--pc-gold)',
          fontSize: '7px',
          background: 'var(--pc-navy)',
          padding: '0 8px',
        }}
      >
        &#9670;
      </div>
    </header>
  );
}
