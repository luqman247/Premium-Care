import { useState } from 'react';
import { icons } from '@/data/signatures';

const iconList = [
  { key: 'phone', name: 'Phone', desc: '1.5px stroke, rounded terminals, geometric curve matching Jost construction' },
  { key: 'mobile', name: 'Mobile', desc: 'Rounded rectangle with minimal detail, hairline stroke throughout' },
  { key: 'email', name: 'Email', desc: 'Envelope with polyline flap, open form, no fill' },
  { key: 'website', name: 'Website', desc: 'Globe with meridian and equator lines, universal symbol' },
  { key: 'location', name: 'Location', desc: 'Map pin with concentric circle target, geometric precision' },
  { key: 'linkedin', name: 'LinkedIn', desc: 'Professional network mark, 1.5px stroke, non-filled' },
  { key: 'facebook', name: 'Facebook', desc: 'Social mark in hairline stroke, gold on light contexts' },
  { key: 'instagram', name: 'Instagram', desc: 'Camera outline with lens circle, rounded corner rectangle' },
] as const;

export default function IconsSection() {
  const [copied, setCopied] = useState<string | null>(null);

  const handleCopy = (key: string, svg: string) => {
    navigator.clipboard.writeText(svg).then(() => {
      setCopied(key);
      setTimeout(() => setCopied(null), 1500);
    });
  };

  return (
    <section id="icons" style={{ padding: '4rem 2rem', maxWidth: '1100px', margin: '0 auto' }}>
      <div className="eyebrow" style={{ fontSize: '8px', marginBottom: '0.75rem' }}>
        Icon System
      </div>
      <h2 className="section-title">Custom Monochrome Icons</h2>
      <p className="section-sub">
        Eight icons drawn at 1.5px hairline stroke, geometric with rounded terminals &mdash; matching Jost&apos;s construction. Single colour only: gold on ivory, navy on ivory contexts.
      </p>
      <div className="gold-hairline" style={{ maxWidth: '400px', margin: '1.5rem 0 2.5rem' }} />

      {/* Icon grid */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
          gap: '1px',
          background: 'rgba(6,29,55,0.08)',
          border: '1px solid rgba(6,29,55,0.08)',
        }}
      >
        {iconList.map(({ key, name, desc }) => {
          const svgHtml = icons[key as keyof typeof icons];
          return (
            <div
              key={key}
              style={{
                background: '#fff',
                padding: '1.75rem 1.5rem',
                display: 'flex',
                alignItems: 'flex-start',
                gap: '1rem',
              }}
            >
              {/* Icon preview */}
              <div
                style={{
                  width: '40px',
                  height: '40px',
                  borderRadius: '3px',
                  background: 'var(--pc-navy)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                }}
                dangerouslySetInnerHTML={{ __html: svgHtml.replace('width="14"', 'width="18"').replace('height="14"', 'height="18"').replace('stroke="#8C6A2D"', 'stroke="#E4C77D"') }}
              />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginBottom: '4px',
                  }}
                >
                  <span
                    style={{
                      fontFamily: "'Jost', sans-serif",
                      fontWeight: 500,
                      fontSize: '11px',
                      color: 'var(--pc-navy)',
                      letterSpacing: '0.06em',
                    }}
                  >
                    {name}
                  </span>
                  <button
                    onClick={() => handleCopy(key, svgHtml)}
                    style={{
                      fontFamily: "'Jost', sans-serif",
                      fontSize: '8px',
                      fontWeight: 500,
                      letterSpacing: '0.14em',
                      textTransform: 'uppercase',
                      color: copied === key ? '#1F6B45' : 'var(--pc-gold-dark)',
                      background: 'transparent',
                      border: 'none',
                      cursor: 'pointer',
                      padding: '2px 4px',
                    }}
                  >
                    {copied === key ? 'Copied' : 'Copy SVG'}
                  </button>
                </div>
                <p
                  style={{
                    fontFamily: "'Jost', sans-serif",
                    fontSize: '9.5px',
                    color: 'var(--pc-muted)',
                    lineHeight: 1.5,
                  }}
                >
                  {desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Icon spec note */}
      <div
        style={{
          marginTop: '1.5rem',
          padding: '1.25rem 1.5rem',
          background: 'rgba(196,160,95,0.06)',
          borderLeft: '2px solid var(--pc-gold)',
        }}
      >
        <p
          style={{
            fontFamily: "'Jost', sans-serif",
            fontSize: '10.5px',
            color: 'var(--pc-muted)',
            lineHeight: 1.7,
          }}
        >
          <strong style={{ color: 'var(--pc-navy)' }}>Icon Specification:</strong> All icons are inline SVGs at 14&times;14px (signature context) or 18&times;18px (UI context). Stroke width: 1.5px. Stroke colour: #8C6A2D (Gold Dark) on light backgrounds, #C4A05F (Regal Gold) on dark backgrounds. No fill, no duotone, no illustrative elements. The crown and shield are never simplified into icons &mdash; the emblem asset is used instead.
        </p>
      </div>
    </section>
  );
}
