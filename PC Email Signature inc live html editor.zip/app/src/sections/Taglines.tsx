import { useState } from 'react';
import { taglines } from '@/data/signatures';

export default function Taglines() {
  const [selected, setSelected] = useState<number[]>([]);

  const toggle = (i: number) => {
    setSelected((prev) =>
      prev.includes(i) ? prev.filter((x) => x !== i) : [...prev, i]
    );
  };

  const copySelected = () => {
    const text = selected.map((i) => taglines[i]).join('\n');
    navigator.clipboard.writeText(text);
  };

  return (
    <section id="taglines" style={{ padding: '4rem 2rem', maxWidth: '1100px', margin: '0 auto' }}>
      <div className="eyebrow" style={{ fontSize: '8px', marginBottom: '0.75rem' }}>
        Executive Taglines
      </div>
      <h2 className="section-title">24 Taglines for Every Occasion</h2>
      <p className="section-sub">
        Each tagline follows the Premium Care voice: warm precision, quiet confidence, no superlatives without evidence.
      </p>
      <div className="gold-hairline" style={{ maxWidth: '400px', margin: '1.5rem 0 2.5rem' }} />

      {selected.length > 0 && (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '0.75rem 1rem',
            background: 'var(--pc-navy)',
            marginBottom: '1.5rem',
          }}
        >
          <span
            style={{
              fontFamily: "'Jost', sans-serif",
              fontSize: '10px',
              fontWeight: 500,
              letterSpacing: '0.14em',
              textTransform: 'uppercase',
              color: 'var(--pc-gold-light)',
            }}
          >
            {selected.length} selected
          </span>
          <button
            onClick={copySelected}
            style={{
              fontFamily: "'Jost', sans-serif",
              fontSize: '9px',
              fontWeight: 500,
              letterSpacing: '0.16em',
              textTransform: 'uppercase',
              color: 'var(--pc-gold)',
              background: 'transparent',
              border: '1px solid rgba(196,160,95,0.4)',
              padding: '5px 16px',
              cursor: 'pointer',
            }}
          >
            Copy Selected
          </button>
        </div>
      )}

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
          gap: '1px',
          background: 'rgba(6,29,55,0.08)',
          border: '1px solid rgba(6,29,55,0.08)',
        }}
      >
        {taglines.map((line, i) => {
          const isSel = selected.includes(i);
          return (
            <button
              key={i}
              onClick={() => toggle(i)}
              style={{
                display: 'block',
                width: '100%',
                textAlign: 'left',
                background: isSel ? 'rgba(196,160,95,0.08)' : '#fff',
                border: 'none',
                padding: '1rem 1.25rem',
                cursor: 'pointer',
                transition: 'all 0.15s',
                position: 'relative',
              }}
            >
              <span
                style={{
                  position: 'absolute',
                  left: '6px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  color: isSel ? 'var(--pc-gold)' : 'transparent',
                  fontSize: '7px',
                }}
              >
                &#9670;
              </span>
              <span
                style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontStyle: 'italic',
                  fontSize: '14px',
                  color: isSel ? 'var(--pc-navy)' : '#39424E',
                  lineHeight: 1.4,
                  paddingLeft: '8px',
                }}
              >
                {line}
              </span>
              <span
                style={{
                  display: 'block',
                  fontFamily: "'Jost', sans-serif",
                  fontSize: '8.5px',
                  color: '#8C949E',
                  letterSpacing: '0.12em',
                  marginTop: '4px',
                  paddingLeft: '8px',
                }}
              >
                #{String(i + 1).padStart(2, '0')}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
