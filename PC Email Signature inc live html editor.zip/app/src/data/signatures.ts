// ============================================================
// PREMIUM CARE EXECUTIVE SIGNATURE SYSTEM
// Production-ready HTML email signatures for
// Luqman Hakim, Founder, CEO & Managing Director
// ============================================================

// --------------------------------------------------------
// VERSION A — LUXURY EXECUTIVE
// Horizontal layout, generous whitespace, gold hairlines,
// device line closure, full contact with labeled icons
// --------------------------------------------------------
export const signatureA_HTML = `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:640px;font-family:'Jost','Segoe UI',Verdana,Arial,sans-serif;color:#061D37;">
  <tr>
    <td style="padding:0 0 18px 0;">
      <!-- Top gold hairline -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-bottom:18px;"><div style="height:1px;background:linear-gradient(90deg,rgba(196,160,95,0.6),rgba(196,160,95,0.15),transparent);"></div></td></tr>
      </table>
      
      <!-- Main content row -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
          <!-- Emblem column -->
          <td width="72" valign="top" style="padding-right:22px;">
            <table cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td width="72" height="72" style="width:72px;height:72px;background:#061D37;border-radius:3px;text-align:center;vertical-align:middle;">
                  <img src="https://i.ibb.co/ emblem-72.png" alt="Premium Care" width="56" height="56" style="display:block;width:56px;height:56px;margin:8px auto;" />
                </td>
              </tr>
              <!-- Diamond below emblem -->
              <tr><td style="text-align:center;padding-top:8px;font-size:7px;color:#C4A05F;line-height:1;">&#9670;</td></tr>
            </table>
          </td>
          
          <!-- Content column -->
          <td valign="top" style="padding-left:4px;">
            <table cellpadding="0" cellspacing="0" border="0">
              <!-- Name -->
              <tr><td style="font-family:'Cinzel',Georgia,'Times New Roman',serif;font-weight:600;font-size:16px;color:#061D37;letter-spacing:0.07em;line-height:1.3;">Luqman Hakim</td></tr>
              
              <!-- Title -->
              <tr><td style="font-family:'Cormorant Garamond',Georgia,serif;font-style:italic;font-size:12px;color:#5A6472;padding-top:3px;line-height:1.4;">Founder, Chief Executive Officer &amp; Managing Director</td></tr>
              
              <!-- Company -->
              <tr><td style="font-family:'Jost',sans-serif;font-weight:500;font-size:8.5px;letter-spacing:0.22em;text-transform:uppercase;color:#8C6A2D;padding-top:6px;line-height:1;">Premium Care ApS</td></tr>
              
              <!-- Gold hairline divider -->
              <tr><td style="padding-top:12px;"><div style="height:1px;width:140px;background:linear-gradient(90deg,#C4A05F,rgba(196,160,95,0));"></div></td></tr>
              
              <!-- Contact details -->
              <tr><td style="padding-top:12px;">
                <table cellpadding="0" cellspacing="0" border="0">
                  <tr>
                    <td style="font-family:'Jost',sans-serif;font-weight:300;font-size:10px;color:#39424E;line-height:2;padding-right:16px;vertical-align:top;">
                      <span style="font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:#8C6A2D;">Direct</span>&nbsp;&nbsp;<a href="tel:+4500000000" style="color:#39424E;text-decoration:none;">+45 00 00 00 00</a><br/>
                      <span style="font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:#8C6A2D;">Mobile</span>&nbsp;&nbsp;<a href="tel:+4500000000" style="color:#39424E;text-decoration:none;">+45 00 00 00 00</a>
                    </td>
                    <td style="font-family:'Jost',sans-serif;font-weight:300;font-size:10px;color:#39424E;line-height:2;vertical-align:top;">
                      <span style="font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:#8C6A2D;">Email</span>&nbsp;&nbsp;<a href="mailto:luqman.hakim@premiumcare.dk" style="color:#39424E;text-decoration:none;border-bottom:1px solid rgba(196,160,95,0.25);">luqman.hakim@premiumcare.dk</a><br/>
                      <span style="font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:#8C6A2D;">Web</span>&nbsp;&nbsp;<a href="https://www.premiumcare.dk" style="color:#39424E;text-decoration:none;">www.premiumcare.dk</a>
                    </td>
                  </tr>
                </table>
              </td></tr>
              
              <!-- Address -->
              <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#5A6472;padding-top:6px;line-height:1.6;">
                [Office Address] &middot; [Postcode] [City] &middot; Danmark<br/>
                <span style="font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:#8C6A2D;">CVR</span>&nbsp;&nbsp;<span style="color:#5A6472;">[CVR Number]</span>
              </td></tr>
            </table>
          </td>
        </tr>
      </table>
      
      <!-- Bottom section -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:16px;"><div style="height:1px;background:linear-gradient(90deg,rgba(196,160,95,0.4),rgba(196,160,95,0.1),transparent);"></div></td></tr>
        <tr>
          <td style="padding-top:8px;">
            <table cellpadding="0" cellspacing="0" border="0" width="100%">
              <tr>
                <td style="font-family:'Jost',sans-serif;font-weight:300;font-size:7.5px;letter-spacing:0.22em;text-transform:uppercase;color:#8C6A2D;vertical-align:middle;">Omsorg &middot; Tryghed &middot; Hver Dag</td>
                <td align="right" style="vertical-align:middle;">
                  <table cellpadding="0" cellspacing="0" border="0"><tr>
                    <td style="padding-left:10px;"><a href="https://linkedin.com/company/premiumcare-aps" style="text-decoration:none;display:block;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a></td>
                    <td style="padding-left:10px;"><a href="https://facebook.com/premiumcareaps" style="text-decoration:none;display:block;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a></td>
                    <td style="padding-left:10px;"><a href="https://instagram.com/premiumcareaps" style="text-decoration:none;display:block;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a></td>
                  </tr></table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>`;

// --------------------------------------------------------
// VERSION A — LUXURY EXECUTIVE (DARK MODE)
// --------------------------------------------------------
export const signatureA_dark_HTML = `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:640px;font-family:'Jost','Segoe UI',Verdana,Arial,sans-serif;color:#F7F5F0;">
  <tr>
    <td style="padding:0 0 18px 0;">
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-bottom:18px;"><div style="height:1px;background:linear-gradient(90deg,rgba(228,199,125,0.5),rgba(228,199,125,0.15),transparent);"></div></td></tr>
      </table>
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
          <td width="72" valign="top" style="padding-right:22px;">
            <table cellpadding="0" cellspacing="0" border="0">
              <tr><td width="72" height="72" style="width:72px;height:72px;background:#04152A;border-radius:3px;border:1px solid rgba(196,160,95,0.2);text-align:center;vertical-align:middle;">
                <img src="https://i.ibb.co/emblem-72.png" alt="Premium Care" width="56" height="56" style="display:block;width:56px;height:56px;margin:8px auto;" />
              </td></tr>
              <tr><td style="text-align:center;padding-top:8px;font-size:7px;color:#C4A05F;line-height:1;">&#9670;</td></tr>
            </table>
          </td>
          <td valign="top" style="padding-left:4px;">
            <table cellpadding="0" cellspacing="0" border="0">
              <tr><td style="font-family:'Cinzel',Georgia,serif;font-weight:600;font-size:16px;color:#F7F5F0;letter-spacing:0.07em;line-height:1.3;">Luqman Hakim</td></tr>
              <tr><td style="font-family:'Cormorant Garamond',Georgia,serif;font-style:italic;font-size:12px;color:#A8B4C4;padding-top:3px;line-height:1.4;">Founder, Chief Executive Officer &amp; Managing Director</td></tr>
              <tr><td style="font-family:'Jost',sans-serif;font-weight:500;font-size:8.5px;letter-spacing:0.22em;text-transform:uppercase;color:#E4C77D;padding-top:6px;line-height:1;">Premium Care ApS</td></tr>
              <tr><td style="padding-top:12px;"><div style="height:1px;width:140px;background:linear-gradient(90deg,#C4A05F,rgba(196,160,95,0));"></div></td></tr>
              <tr><td style="padding-top:12px;">
                <table cellpadding="0" cellspacing="0" border="0">
                  <tr>
                    <td style="font-family:'Jost',sans-serif;font-weight:300;font-size:10px;color:#C9CFD8;line-height:2;padding-right:16px;vertical-align:top;">
                      <span style="font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:#E4C77D;">Direct</span>&nbsp;&nbsp;<a href="tel:+4500000000" style="color:#C9CFD8;text-decoration:none;">+45 00 00 00 00</a><br/>
                      <span style="font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:#E4C77D;">Mobile</span>&nbsp;&nbsp;<a href="tel:+4500000000" style="color:#C9CFD8;text-decoration:none;">+45 00 00 00 00</a>
                    </td>
                    <td style="font-family:'Jost',sans-serif;font-weight:300;font-size:10px;color:#C9CFD8;line-height:2;vertical-align:top;">
                      <span style="font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:#E4C77D;">Email</span>&nbsp;&nbsp;<a href="mailto:luqman.hakim@premiumcare.dk" style="color:#C9CFD8;text-decoration:none;border-bottom:1px solid rgba(196,160,95,0.25);">luqman.hakim@premiumcare.dk</a><br/>
                      <span style="font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:#E4C77D;">Web</span>&nbsp;&nbsp;<a href="https://www.premiumcare.dk" style="color:#C9CFD8;text-decoration:none;">www.premiumcare.dk</a>
                    </td>
                  </tr>
                </table>
              </td></tr>
              <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#8C949E;padding-top:6px;line-height:1.6;">[Office Address] &middot; [Postcode] [City] &middot; Danmark<br/><span style="font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:#E4C77D;">CVR</span>&nbsp;&nbsp;<span style="color:#8C949E;">[CVR Number]</span></td></tr>
            </table>
          </td>
        </tr>
      </table>
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:16px;"><div style="height:1px;background:linear-gradient(90deg,rgba(228,199,125,0.3),rgba(228,199,125,0.1),transparent);"></div></td></tr>
        <tr><td style="padding-top:8px;">
          <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
            <td style="font-family:'Jost',sans-serif;font-weight:300;font-size:7.5px;letter-spacing:0.22em;text-transform:uppercase;color:#C4A05F;vertical-align:middle;">Omsorg &middot; Tryghed &middot; Hver Dag</td>
            <td align="right" style="vertical-align:middle;">
              <table cellpadding="0" cellspacing="0" border="0"><tr>
                <td style="padding-left:10px;"><a href="https://linkedin.com/company/premiumcare-aps" style="text-decoration:none;display:block;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#C4A05F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a></td>
                <td style="padding-left:10px;"><a href="https://facebook.com/premiumcareaps" style="text-decoration:none;display:block;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#C4A05F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a></td>
                <td style="padding-left:10px;"><a href="https://instagram.com/premiumcareaps" style="text-decoration:none;display:block;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#C4A05F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a></td>
              </tr></table>
            </td>
          </tr></table>
        </td></tr>
      </table>
    </td>
  </tr>
</table>`;

// --------------------------------------------------------
// VERSION B — MODERN SCANDINAVIAN
// Inspired by Apple & Bang & Olufsen
// Very clean, minimal decoration, typography-driven
// --------------------------------------------------------
export const signatureB_HTML = `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:520px;font-family:'Jost','Segoe UI',Verdana,Arial,sans-serif;color:#061D37;">
  <tr>
    <td style="padding:0;">
      <!-- Name -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="font-family:'Cinzel',Georgia,serif;font-weight:600;font-size:15px;color:#061D37;letter-spacing:0.06em;line-height:1.2;">Luqman Hakim</td></tr>
        <tr><td style="font-family:'Jost',sans-serif;font-weight:400;font-size:9px;letter-spacing:0.16em;text-transform:uppercase;color:#5A6472;padding-top:4px;line-height:1.4;">Founder &nbsp;&middot;&nbsp; Chief Executive Officer &nbsp;&middot;&nbsp; Managing Director</td></tr>
      </table>
      
      <!-- Single hairline -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:14px;padding-bottom:14px;"><div style="height:1px;width:100%;background:linear-gradient(90deg,#C4A05F,rgba(196,160,95,0.12));"></div></td></tr>
      </table>
      
      <!-- Contact grid -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
          <td width="50%" valign="top" style="padding-right:12px;">
            <table cellpadding="0" cellspacing="0" border="0">
              <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#39424E;line-height:1.9;">
                <a href="tel:+4500000000" style="color:#39424E;text-decoration:none;">+45 00 00 00 00</a>
              </td></tr>
              <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#39424E;line-height:1.9;">
                <a href="mailto:luqman.hakim@premiumcare.dk" style="color:#39424E;text-decoration:none;">luqman.hakim@premiumcare.dk</a>
              </td></tr>
            </table>
          </td>
          <td width="50%" valign="top" style="padding-left:12px;">
            <table cellpadding="0" cellspacing="0" border="0">
              <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#39424E;line-height:1.9;">
                <a href="https://www.premiumcare.dk" style="color:#39424E;text-decoration:none;">www.premiumcare.dk</a>
              </td></tr>
              <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9px;color:#5A6472;line-height:1.9;">[Office Address]</td></tr>
            </table>
          </td>
        </tr>
      </table>
      
      <!-- Bottom -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:16px;"><div style="height:1px;width:60px;background:#C4A05F;opacity:0.5;"></div></td></tr>
        <tr><td style="padding-top:8px;">
          <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
            <td style="font-family:'Jost',sans-serif;font-weight:500;font-size:7.5px;letter-spacing:0.24em;text-transform:uppercase;color:#8C6A2D;vertical-align:middle;">Premium Care ApS</td>
            <td align="right" style="vertical-align:middle;">
              <table cellpadding="0" cellspacing="0" border="0"><tr>
                <td style="padding-left:8px;"><a href="https://linkedin.com/company/premiumcare-aps" style="text-decoration:none;display:block;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a></td>
                <td style="padding-left:8px;"><a href="https://facebook.com/premiumcareaps" style="text-decoration:none;display:block;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a></td>
                <td style="padding-left:8px;"><a href="https://instagram.com/premiumcareaps" style="text-decoration:none;display:block;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a></td>
              </tr></table>
            </td>
          </tr></table>
        </td></tr>
      </table>
    </td>
  </tr>
</table>`;

// --------------------------------------------------------
// VERSION B — DARK MODE
// --------------------------------------------------------
export const signatureB_dark_HTML = `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:520px;font-family:'Jost','Segoe UI',Verdana,Arial,sans-serif;color:#F7F5F0;">
  <tr>
    <td style="padding:0;">
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="font-family:'Cinzel',Georgia,serif;font-weight:600;font-size:15px;color:#F7F5F0;letter-spacing:0.06em;line-height:1.2;">Luqman Hakim</td></tr>
        <tr><td style="font-family:'Jost',sans-serif;font-weight:400;font-size:9px;letter-spacing:0.16em;text-transform:uppercase;color:#8C949E;padding-top:4px;line-height:1.4;">Founder &nbsp;&middot;&nbsp; Chief Executive Officer &nbsp;&middot;&nbsp; Managing Director</td></tr>
      </table>
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:14px;padding-bottom:14px;"><div style="height:1px;width:100%;background:linear-gradient(90deg,#C4A05F,rgba(196,160,95,0.15));"></div></td></tr>
      </table>
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
          <td width="50%" valign="top" style="padding-right:12px;">
            <table cellpadding="0" cellspacing="0" border="0">
              <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#C9CFD8;line-height:1.9;"><a href="tel:+4500000000" style="color:#C9CFD8;text-decoration:none;">+45 00 00 00 00</a></td></tr>
              <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#C9CFD8;line-height:1.9;"><a href="mailto:luqman.hakim@premiumcare.dk" style="color:#C9CFD8;text-decoration:none;">luqman.hakim@premiumcare.dk</a></td></tr>
            </table>
          </td>
          <td width="50%" valign="top" style="padding-left:12px;">
            <table cellpadding="0" cellspacing="0" border="0">
              <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#C9CFD8;line-height:1.9;"><a href="https://www.premiumcare.dk" style="color:#C9CFD8;text-decoration:none;">www.premiumcare.dk</a></td></tr>
              <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9px;color:#8C949E;line-height:1.9;">[Office Address]</td></tr>
            </table>
          </td>
        </tr>
      </table>
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:16px;"><div style="height:1px;width:60px;background:#C4A05F;opacity:0.5;"></div></td></tr>
        <tr><td style="padding-top:8px;">
          <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
            <td style="font-family:'Jost',sans-serif;font-weight:500;font-size:7.5px;letter-spacing:0.24em;text-transform:uppercase;color:#E4C77D;vertical-align:middle;">Premium Care ApS</td>
            <td align="right" style="vertical-align:middle;">
              <table cellpadding="0" cellspacing="0" border="0"><tr>
                <td style="padding-left:8px;"><a href="https://linkedin.com/company/premiumcare-aps" style="text-decoration:none;display:block;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#C4A05F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a></td>
                <td style="padding-left:8px;"><a href="https://facebook.com/premiumcareaps" style="text-decoration:none;display:block;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#C4A05F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a></td>
                <td style="padding-left:8px;"><a href="https://instagram.com/premiumcareaps" style="text-decoration:none;display:block;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#C4A05F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a></td>
              </tr></table>
            </td>
          </tr></table>
        </td></tr>
      </table>
    </td>
  </tr>
</table>`;

// --------------------------------------------------------
// VERSION C — ULTRA MINIMAL
// Museum-quality spacing, typography-dominant
// Almost no decoration. Luxury publishing aesthetic.
// --------------------------------------------------------
export const signatureC_HTML = `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:420px;font-family:'Jost','Segoe UI',Verdana,Arial,sans-serif;color:#061D37;">
  <tr>
    <td style="padding:0 0 2px 0;">
      <!-- Name only, with generous space -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="font-family:'Cinzel',Georgia,serif;font-weight:600;font-size:14px;color:#061D37;letter-spacing:0.08em;line-height:1.25;">Luqman Hakim</td></tr>
        <tr><td style="font-family:'Cormorant Garamond',Georgia,serif;font-style:italic;font-size:11px;color:#5A6472;padding-top:5px;line-height:1.4;">Founder &middot; CEO &middot; Managing Director</td></tr>
      </table>
      
      <!-- Minimal divider -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:16px;padding-bottom:14px;"><div style="height:1px;width:48px;background:#C4A05F;"></div></td></tr>
      </table>
      
      <!-- Essential contact only -->
      <table cellpadding="0" cellspacing="0" border="0">
        <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#39424E;line-height:1.8;">
          <a href="mailto:luqman.hakim@premiumcare.dk" style="color:#39424E;text-decoration:none;">luqman.hakim@premiumcare.dk</a>
        </td></tr>
        <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#39424E;line-height:1.8;">
          <a href="https://www.premiumcare.dk" style="color:#39424E;text-decoration:none;">www.premiumcare.dk</a>
        </td></tr>
      </table>
      
      <!-- Company -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:20px;">
          <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
            <td style="font-family:'Jost',sans-serif;font-weight:400;font-size:7px;letter-spacing:0.28em;text-transform:uppercase;color:#8C6A2D;vertical-align:middle;">Premium Care ApS</td>
            <td align="right" style="vertical-align:middle;">
              <span style="font-family:'Jost',sans-serif;font-size:7px;letter-spacing:0.18em;text-transform:uppercase;color:#8C6A2D;">Omsorg &middot; Tryghed &middot; Hver Dag</span>
            </td>
          </tr></table>
        </td></tr>
      </table>
    </td>
  </tr>
</table>`;

// --------------------------------------------------------
// VERSION C — DARK MODE
// --------------------------------------------------------
export const signatureC_dark_HTML = `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:420px;font-family:'Jost','Segoe UI',Verdana,Arial,sans-serif;color:#F7F5F0;">
  <tr>
    <td style="padding:0 0 2px 0;">
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="font-family:'Cinzel',Georgia,serif;font-weight:600;font-size:14px;color:#F7F5F0;letter-spacing:0.08em;line-height:1.25;">Luqman Hakim</td></tr>
        <tr><td style="font-family:'Cormorant Garamond',Georgia,serif;font-style:italic;font-size:11px;color:#A8B4C4;padding-top:5px;line-height:1.4;">Founder &middot; CEO &middot; Managing Director</td></tr>
      </table>
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:16px;padding-bottom:14px;"><div style="height:1px;width:48px;background:#C4A05F;"></div></td></tr>
      </table>
      <table cellpadding="0" cellspacing="0" border="0">
        <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#C9CFD8;line-height:1.8;"><a href="mailto:luqman.hakim@premiumcare.dk" style="color:#C9CFD8;text-decoration:none;">luqman.hakim@premiumcare.dk</a></td></tr>
        <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#C9CFD8;line-height:1.8;"><a href="https://www.premiumcare.dk" style="color:#C9CFD8;text-decoration:none;">www.premiumcare.dk</a></td></tr>
      </table>
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:20px;">
          <table cellpadding="0" cellspacing="0" border="0" width="100%"><tr>
            <td style="font-family:'Jost',sans-serif;font-weight:400;font-size:7px;letter-spacing:0.28em;text-transform:uppercase;color:#C4A05F;vertical-align:middle;">Premium Care ApS</td>
            <td align="right" style="vertical-align:middle;"><span style="font-family:'Jost',sans-serif;font-size:7px;letter-spacing:0.18em;text-transform:uppercase;color:#C4A05F;">Omsorg &middot; Tryghed &middot; Hver Dag</span></td>
          </tr></table>
        </td></tr>
      </table>
    </td>
  </tr>
</table>`;

// --------------------------------------------------------
// MOBILE VERSION (Responsive Compact)
// Stacked layout for narrow viewports
// --------------------------------------------------------
export const signatureMobile_HTML = `<table cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:320px;font-family:'Jost','Segoe UI',Verdana,Arial,sans-serif;color:#061D37;">
  <tr>
    <td style="padding:0;">
      <!-- Name -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="font-family:'Cinzel',Georgia,serif;font-weight:600;font-size:13px;color:#061D37;letter-spacing:0.06em;line-height:1.25;">Luqman Hakim</td></tr>
        <tr><td style="font-family:'Jost',sans-serif;font-weight:400;font-size:8px;letter-spacing:0.14em;text-transform:uppercase;color:#8C6A2D;padding-top:3px;line-height:1.3;">Founder &middot; CEO &middot; Managing Director</td></tr>
      </table>
      
      <!-- Divider -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:10px;padding-bottom:10px;"><div style="height:1px;width:80px;background:linear-gradient(90deg,#C4A05F,rgba(196,160,95,0));"></div></td></tr>
      </table>
      
      <!-- Contact -->
      <table cellpadding="0" cellspacing="0" border="0">
        <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#39424E;line-height:1.85;">
          <a href="tel:+4500000000" style="color:#39424E;text-decoration:none;">+45 00 00 00 00</a>
        </td></tr>
        <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#39424E;line-height:1.85;">
          <a href="mailto:luqman.hakim@premiumcare.dk" style="color:#39424E;text-decoration:none;">luqman.hakim@premiumcare.dk</a>
        </td></tr>
        <tr><td style="font-family:'Jost',sans-serif;font-weight:300;font-size:9.5px;color:#39424E;line-height:1.85;">
          <a href="https://www.premiumcare.dk" style="color:#39424E;text-decoration:none;">www.premiumcare.dk</a>
        </td></tr>
      </table>
      
      <!-- Bottom -->
      <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr><td style="padding-top:12px;"><div style="height:1px;width:40px;background:#C4A05F;opacity:0.5;"></div></td></tr>
        <tr><td style="padding-top:6px;font-family:'Jost',sans-serif;font-weight:400;font-size:7px;letter-spacing:0.22em;text-transform:uppercase;color:#8C6A2D;">Premium Care ApS</td></tr>
      </table>
    </td>
  </tr>
</table>`;

// --------------------------------------------------------
// PLAIN TEXT VERSION
// --------------------------------------------------------
export const signaturePlainText = `--
Luqman Hakim
Founder, Chief Executive Officer & Managing Director
Premium Care ApS

Direct:    +45 00 00 00 00
Mobile:    +45 00 00 00 00
Email:     luqman.hakim@premiumcare.dk
Web:       www.premiumcare.dk

[Office Address]
[Postcode] [City], Danmark
CVR: [CVR Number]

LinkedIn:  linkedin.com/company/premiumcare-aps

Premium Care ApS | Omsorg * Tryghed * Hver Dag`;

// --------------------------------------------------------
// EXECUTIVE TAGLINES
// --------------------------------------------------------
export const taglines = [
  "Delivering Premium Care with Compassion.",
  "Exceptional Care. Exceptional Standards.",
  "Professional Care. Personal Commitment.",
  "Where Care Meets Excellence.",
  "Compassion Delivered Professionally.",
  "Denmark's Highest Standard of Care, at Home.",
  "Care Planned with Precision. Delivered with Heart.",
  "The Same Faces. The Agreed Times. The Promised Standard.",
  "Quietly Raising the Standard of Danish Care.",
  "Dignity First. Always.",
  "Your Home. Your Routine. Your Life. We Fit Around You.",
  "Trust Built Through Continuity.",
  "Care Worthy of Denmark's Finest Tradition.",
  "Every Visit, Every Day, Every Standard Met.",
  "Unhurried Care for the People Who Built Our World.",
  "Where Danish Values Meet Clinical Excellence.",
  "Not Just Care. A Relationship.",
  "The Standard Others Are Measured Against.",
  "Omsorg. Tryghed. Hver Dag.",
  "Care as It Should Be.",
  "Setting the Benchmark for Private Home Care in Denmark.",
  "For Those Who Will Not Compromise on Care.",
  "Discreet. Dignified. Danish.",
  "Continuity is Not a Feature. It is the Foundation.",
];

// --------------------------------------------------------
// CUSTOM ICON SVGs (inline, for email use)
// All 1.5px stroke, geometric, matching Jost construction
// --------------------------------------------------------
export const icons = {
  phone: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,

  mobile: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>`,

  email: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>`,

  website: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>`,

  location: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>`,

  linkedin: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>`,

  facebook: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>`,

  instagram: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8C6A2D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>`,
};
