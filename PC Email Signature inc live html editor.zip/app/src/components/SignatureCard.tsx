import { useState } from 'react';
import CodeBlock from './CodeBlock';

interface SignatureCardProps {
  title: string;
  tag: string;
  lightHtml: string;
  darkHtml: string;
  description: string;
  rationale: string[];
}

export default function SignatureCard({
  title,
  tag,
  lightHtml,
  darkHtml,
  description,
  rationale,
}: SignatureCardProps) {
  const [mode, setMode] = useState<'light' | 'dark'>('light');
  const [showCode, setShowCode] = useState(false);

  return (
    <div className="sig-card" style={{ marginBottom: '2.5rem' }}>
      {/* Header */}
      <div className="sig-card-header">
        <h3>{title}</h3>
        <span className="tag">{tag}</span>
      </div>

      {/* Description */}
      <div style={{ padding: '1.25rem 1.5rem 0.5rem', background: '#fff' }}>
        <p
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontStyle: 'italic',
            fontSize: '13px',
            color: 'var(--pc-muted)',
            lineHeight: 1.5,
          }}
        >
          {description}
        </p>
      </div>

      {/* Mode toggle */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0',
          padding: '0.75rem 1.5rem',
          background: '#fff',
          borderBottom: '1px solid rgba(6,29,55,0.06)',
        }}
      >
        <button
          onClick={() => setMode('light')}
          style={{
            fontFamily: "'Jost', sans-serif",
            fontSize: '9px',
            fontWeight: 500,
            letterSpacing: '0.16em',
            textTransform: 'uppercase',
            padding: '5px 14px',
            border: '1px solid',
            borderColor:
              mode === 'light'
                ? 'rgba(196,160,95,0.5)'
                : 'rgba(6,29,55,0.1)',
            background:
              mode === 'light' ? 'rgba(196,160,95,0.08)' : 'transparent',
            color: mode === 'light' ? 'var(--pc-gold-dark)' : '#8C949E',
            cursor: 'pointer',
            transition: 'all 0.2s',
          }}
        >
          Light
        </button>
        <button
          onClick={() => setMode('dark')}
          style={{
            fontFamily: "'Jost', sans-serif",
            fontSize: '9px',
            fontWeight: 500,
            letterSpacing: '0.16em',
            textTransform: 'uppercase',
            padding: '5px 14px',
            border: '1px solid',
            borderColor:
              mode === 'dark'
                ? 'rgba(196,160,95,0.5)'
                : 'rgba(6,29,55,0.1)',
            background:
              mode === 'dark' ? 'rgba(196,160,95,0.08)' : 'transparent',
            color: mode === 'dark' ? 'var(--pc-gold-dark)' : '#8C949E',
            cursor: 'pointer',
            transition: 'all 0.2s',
          }}
        >
          Dark
        </button>
        <div style={{ flex: 1 }} />
        <button
          onClick={() => setShowCode(!showCode)}
          style={{
            fontFamily: "'Jost', sans-serif",
            fontSize: '9px',
            fontWeight: 500,
            letterSpacing: '0.16em',
            textTransform: 'uppercase',
            padding: '5px 14px',
            border: '1px solid rgba(6,29,55,0.15)',
            background: 'transparent',
            color: 'var(--pc-muted)',
            cursor: 'pointer',
            transition: 'all 0.2s',
          }}
        >
          {showCode ? 'Hide Code' : 'View HTML'}
        </button>
      </div>

      {/* Preview */}
      <div
        className={mode === 'light' ? 'sig-preview-light' : 'sig-preview-dark'}
        style={{ minHeight: '180px' }}
      >
        <div
          dangerouslySetInnerHTML={{
            __html: mode === 'light' ? lightHtml : darkHtml,
          }}
        />
      </div>

      {/* Code block */}
      {showCode && (
        <CodeBlock
          code={mode === 'light' ? lightHtml : darkHtml}
          id={`sig-${title.replace(/\s/g, '-').toLowerCase()}-${mode}`}
          label={`${mode === 'light' ? 'Light' : 'Dark'} Mode HTML`}
        />
      )}

      {/* Design rationale bullets */}
      <div
        style={{
          padding: '1.25rem 1.5rem',
          background: 'var(--pc-ivory)',
          borderTop: '1px solid rgba(6,29,55,0.06)',
        }}
      >
        <div
          className="eyebrow"
          style={{
            fontSize: '7px',
            marginBottom: '0.75rem',
            color: 'var(--pc-gold-dark)',
          }}
        >
          Design Decisions
        </div>
        <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
          {rationale.map((item, i) => (
            <li
              key={i}
              style={{
                fontFamily: "'Jost', sans-serif",
                fontSize: '10.5px',
                color: 'var(--pc-grey)',
                lineHeight: 1.7,
                paddingLeft: '14px',
                position: 'relative',
                marginBottom: '4px',
              }}
            >
              <span
                style={{
                  position: 'absolute',
                  left: 0,
                  color: 'var(--pc-gold)',
                  fontSize: '8px',
                }}
              >
                &#9670;
              </span>
              {item}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
