import { useState } from 'react';

interface CodeBlockProps {
  code: string;
  id: string;
  label?: string;
}

export default function CodeBlock({ code, id, label }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  };

  return (
    <div className="code-block" style={{ borderRadius: 0 }}>
      <div className="flex items-center justify-between mb-2">
        {label && (
          <span className="eyebrow" style={{ color: 'var(--pc-gold-dark)', fontSize: '7px' }}>
            {label}
          </span>
        )}
        <button className="copy-btn" onClick={handleCopy} style={{ float: 'none' }}>
          {copied ? 'Copied' : 'Copy HTML'}
        </button>
      </div>
      <pre id={id}>{code}</pre>
    </div>
  );
}
