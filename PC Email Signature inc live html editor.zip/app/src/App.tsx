import { useState, useCallback, useRef, useEffect } from 'react';
import type { SignatureConfig } from './lib/generator';
import {
  defaultConfig,
  generateLuxury,
  generateModern,
  generateMinimal,
  generateMobile,
  generatePlainText,
} from './lib/generator';

// ============================================================
// PREMIUM CARE EXECUTIVE SIGNATURE BUILDER v2.0
// With official logo integration throughout
// ============================================================

type Version = 'luxury' | 'modern' | 'minimal';
type Mode = 'light' | 'dark';
type ExportFormat = 'html' | 'outlook' | 'gmail' | 'plaintext';

const taglines = [
  'Delivering Premium Care with Compassion.',
  'Exceptional Care. Exceptional Standards.',
  'Professional Care. Personal Commitment.',
  'Where Care Meets Excellence.',
  'Compassion Delivered Professionally.',
  "Denmark's Highest Standard of Care, at Home.",
  'Care Planned with Precision. Delivered with Heart.',
  'The Same Faces. The Agreed Times. The Promised Standard.',
  'Quietly Raising the Standard of Danish Care.',
  'Dignity First. Always.',
  'Your Home. Your Routine. Your Life. We Fit Around You.',
  'Trust Built Through Continuity.',
  'Care Worthy of Denmark\'s Finest Tradition.',
  'Every Visit, Every Day, Every Standard Met.',
  'Unhurried Care for the People Who Built Our World.',
  'Where Danish Values Meet Clinical Excellence.',
  'Not Just Care. A Relationship.',
  'The Standard Others Are Measured Against.',
  'Omsorg. Tryghed. Hver Dag.',
  'Care as It Should Be.',
  'Setting the Benchmark for Private Home Care in Denmark.',
  'For Those Who Will Not Compromise on Care.',
  'Discreet. Dignified. Danish.',
  'Continuity is Not a Feature. It is the Foundation.',
];

// ---- Brand-styled components ----
function Eyebrow({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{
      fontFamily: "'Jost', sans-serif",
      fontWeight: 500,
      fontSize: '8px',
      letterSpacing: '0.32em',
      textTransform: 'uppercase',
      color: '#8C6A2D',
      ...style,
    }}>
      {children}
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <label style={{
      fontFamily: "'Jost', sans-serif",
      fontWeight: 500,
      fontSize: '8.5px',
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      color: '#8C6A2D',
      display: 'block',
      marginBottom: '6px',
    }}>
      {children}
    </label>
  );
}

function Input({ value, onChange, placeholder, type = 'text' }: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <input
      type={type}
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      style={{
        fontFamily: "'Jost', sans-serif",
        fontWeight: 400,
        fontSize: '12px',
        color: '#061D37',
        background: '#fff',
        border: '1px solid rgba(6,29,55,0.1)',
        borderRadius: '2px',
        padding: '8px 12px',
        width: '100%',
        outline: 'none',
        transition: 'border-color 0.2s',
      }}
      onFocus={e => e.currentTarget.style.borderColor = 'rgba(196,160,95,0.5)'}
      onBlur={e => e.currentTarget.style.borderColor = 'rgba(6,29,55,0.1)'}
    />
  );
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        background: 'transparent',
        border: 'none',
        cursor: 'pointer',
        padding: '4px 0',
      }}
    >
      <div style={{
        width: '32px',
        height: '18px',
        borderRadius: '9px',
        background: checked ? '#C4A05F' : 'rgba(6,29,55,0.12)',
        position: 'relative',
        transition: 'background 0.2s',
      }}>
        <div style={{
          width: '14px',
          height: '14px',
          borderRadius: '50%',
          background: '#fff',
          position: 'absolute',
          top: '2px',
          left: checked ? '16px' : '2px',
          transition: 'left 0.2s',
          boxShadow: '0 1px 3px rgba(0,0,0,0.15)',
        }} />
      </div>
      <span style={{ fontFamily: "'Jost', sans-serif", fontSize: '11px', fontWeight: 400, color: '#39424E' }}>{label}</span>
    </button>
  );
}

function GoldHairline({ width = '100%', style }: { width?: string; style?: React.CSSProperties }) {
  return (
    <div style={{
      height: '1px',
      width,
      background: 'linear-gradient(90deg, #C4A05F, rgba(196,160,95,0))',
      ...style,
    }} />
  );
}

function DiamondSeparator() {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
    }}>
      <GoldHairline style={{ flex: 1 }} />
      <span style={{ color: '#C4A05F', fontSize: '7px', letterSpacing: '0.4em' }}>&#9670; &#9670; &#9670;</span>
      <GoldHairline style={{ flex: 1 }} />
    </div>
  );
}

// ---- Main App ----
export default function App() {
  const [config, setConfig] = useState<SignatureConfig>(defaultConfig);
  const [version, setVersion] = useState<Version>('luxury');
  const [mode, setMode] = useState<Mode>('light');
  const [showExport, setShowExport] = useState(false);
  const [exportFormat, setExportFormat] = useState<ExportFormat>('html');
  const [copied, setCopied] = useState(false);
  const [copiedTagline, setCopiedTagline] = useState<number | null>(null);
  const exportRef = useRef<HTMLDivElement>(null);

  const updateField = useCallback(<K extends keyof SignatureConfig>(field: K, value: SignatureConfig[K]) => {
    setConfig(prev => ({ ...prev, [field]: value }));
  }, []);

  const generatedHTML = version === 'luxury' ? generateLuxury(config, mode === 'dark')
    : version === 'modern' ? generateModern(config, mode === 'dark')
    : generateMinimal(config, mode === 'dark');

  const mobileHTML = generateMobile(config, mode === 'dark');
  const plainText = generatePlainText(config);
  const outlookHTML = `<html><body style="margin:0;padding:0;font-family:'Jost','Segoe UI',Arial,sans-serif;">${generatedHTML}</body></html>`;
  const gmailHTML = generatedHTML;

  const getExportContent = () => {
    switch (exportFormat) {
      case 'html': return generatedHTML;
      case 'outlook': return outlookHTML;
      case 'gmail': return gmailHTML;
      case 'plaintext': return plainText;
    }
  };

  const handleCopy = useCallback((text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, []);

  useEffect(() => {
    if (showExport && exportRef.current) {
      exportRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [showExport]);

  const versions: { key: Version; label: string; desc: string }[] = [
    { key: 'luxury', label: 'Version A — Luxury Executive', desc: 'Emblem on navy \u00b7 Gold hairlines \u00b7 Full detail' },
    { key: 'modern', label: 'Version B — Modern Scandinavian', desc: 'Horizontal logo \u00b7 Typography-driven \u00b7 Minimal' },
    { key: 'minimal', label: 'Version C — Ultra Minimal', desc: 'Small emblem accent \u00b7 Museum quality' },
  ];

  // Signature card header colour based on version
  const versionLabel = version === 'luxury' ? '640px max' : version === 'modern' ? '520px max' : '420px max';

  return (
    <div style={{ minHeight: '100vh', background: '#F7F5F0' }}>

      {/* ===== HEADER with real logo ===== */}
      <header style={{
        background: '#061D37',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Gold hairline frame */}
        <div style={{
          position: 'absolute',
          inset: '12px',
          border: '0.5px solid rgba(196,160,95,0.28)',
          pointerEvents: 'none',
          borderRadius: '1px',
        }} />
        {/* Diamond at top center */}
        <div style={{
          position: 'absolute',
          top: '7px',
          left: '50%',
          transform: 'translateX(-50%)',
          color: '#C4A05F',
          fontSize: '7px',
          background: '#061D37',
          padding: '0 10px',
          letterSpacing: '0.5em',
        }}>&#9670; &#9670; &#9670;</div>

        <div style={{
          maxWidth: '1200px',
          margin: '0 auto',
          padding: '2.5rem 2rem 2rem',
          textAlign: 'center',
        }}>
          {/* Logo */}
          <img
            src="/logo/horizontal/horizontal_120.png"
            alt="Premium Care"
            style={{
              width: '100px',
              height: 'auto',
              marginBottom: '1.25rem',
              opacity: 0.95,
            }}
          />

          <Eyebrow style={{ color: '#C4A05F', marginBottom: '0.75rem', letterSpacing: '0.36em' }}>
            Email Identity System &middot; Interactive Builder
          </Eyebrow>

          <h1 style={{
            fontFamily: "'Cinzel', serif",
            fontWeight: 600,
            fontSize: 'clamp(16px, 3vw, 24px)',
            color: '#F7F5F0',
            letterSpacing: '0.18em',
            lineHeight: 1.2,
            marginBottom: '0.5rem',
          }}>
            EXECUTIVE SIGNATURE BUILDER
          </h1>

          <p style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontStyle: 'italic',
            fontSize: '14px',
            color: '#8FA0B8',
            marginBottom: '1rem',
          }}>
            Edit in real time &middot; Switch versions &middot; Toggle light &amp; dark &middot; Export production HTML
          </p>

          <DiamondSeparator />

          {/* Bottom diamond */}
          <div style={{
            position: 'absolute',
            bottom: '7px',
            left: '50%',
            transform: 'translateX(-50%)',
            color: '#C4A05F',
            fontSize: '7px',
            background: '#061D37',
            padding: '0 8px',
          }}>&#9670;</div>
        </div>
      </header>

      {/* ===== MAIN GRID ===== */}
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        padding: '2rem',
        display: 'grid',
        gridTemplateColumns: '300px 1fr',
        gap: '2rem',
      }}>

        {/* ===== LEFT: EDITOR PANEL ===== */}
        <div style={{ position: 'sticky', top: '20px', alignSelf: 'start' }}>
          <div style={{
            background: '#fff',
            border: '1px solid rgba(6,29,55,0.08)',
            overflow: 'hidden',
          }}>
            {/* Panel header with crown motif */}
            <div style={{
              background: '#061D37',
              padding: '0.7rem 1.25rem',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
            }}>
              <img src="/logo/emblem/emblem_32.png" alt="" style={{ width: '20px', height: 'auto', opacity: 0.7 }} />
              <span style={{
                fontFamily: "'Jost', sans-serif",
                fontWeight: 500,
                fontSize: '9.5px',
                letterSpacing: '0.2em',
                textTransform: 'uppercase',
                color: '#E4C77D',
              }}>Editor</span>
            </div>

            <div style={{
              padding: '1.25rem',
              maxHeight: 'calc(100vh - 180px)',
              overflowY: 'auto',
            }}>

              {/* Version Switcher */}
              <div style={{ marginBottom: '1.25rem' }}>
                <Label>Signature Version</Label>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  {versions.map(v => (
                    <button
                      key={v.key}
                      onClick={() => setVersion(v.key)}
                      style={{
                        textAlign: 'left',
                        padding: '10px 12px',
                        border: version === v.key
                          ? '1px solid rgba(196,160,95,0.45)'
                          : '1px solid rgba(6,29,55,0.08)',
                        background: version === v.key ? 'rgba(196,160,95,0.05)' : 'transparent',
                        cursor: 'pointer',
                        borderRadius: '2px',
                        transition: 'all 0.15s',
                      }}
                    >
                      <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                      }}>
                        {v.key === 'luxury' && (
                          <img src="/logo/emblem/emblem_32.png" alt="" style={{ width: '20px', height: 'auto', opacity: version === v.key ? 1 : 0.5 }} />
                        )}
                        {v.key === 'modern' && (
                          <img src="/logo/horizontal/horizontal_120.png" alt="" style={{ width: '28px', height: 'auto', opacity: version === v.key ? 1 : 0.5 }} />
                        )}
                        {v.key === 'minimal' && (
                          <img src="/logo/emblem/emblem_32.png" alt="" style={{ width: '16px', height: 'auto', opacity: version === v.key ? 0.7 : 0.35 }} />
                        )}
                        <div>
                          <div style={{
                            fontFamily: "'Jost', sans-serif",
                            fontWeight: 500,
                            fontSize: '10px',
                            color: version === v.key ? '#061D37' : '#39424E',
                            letterSpacing: '0.06em',
                          }}>{v.label}</div>
                          <div style={{
                            fontFamily: "'Jost', sans-serif",
                            fontWeight: 300,
                            fontSize: '8px',
                            color: '#8C949E',
                            marginTop: '2px',
                            letterSpacing: '0.04em',
                          }}>{v.desc}</div>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Light/Dark */}
              <div style={{
                marginBottom: '1.25rem',
                paddingBottom: '1.25rem',
                borderBottom: '1px solid rgba(6,29,55,0.06)',
              }}>
                <Label>Preview Mode</Label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  {(['light', 'dark'] as const).map(m => (
                    <button
                      key={m}
                      onClick={() => setMode(m)}
                      style={{
                        flex: 1,
                        padding: '8px',
                        fontFamily: "'Jost', sans-serif",
                        fontSize: '10px',
                        fontWeight: 500,
                        letterSpacing: '0.14em',
                        textTransform: 'uppercase',
                        border: mode === m ? '1px solid rgba(196,160,95,0.45)' : '1px solid rgba(6,29,55,0.08)',
                        background: mode === m ? 'rgba(196,160,95,0.05)' : '#fff',
                        color: mode === m ? '#061D37' : '#8C949E',
                        cursor: 'pointer',
                        borderRadius: '2px',
                        transition: 'all 0.15s',
                      }}
                    >{m}</button>
                  ))}
                </div>
              </div>

              {/* Name & Title */}
              <div style={{ marginBottom: '0.75rem' }}><Label>Full Name</Label><Input value={config.name} onChange={v => updateField('name', v)} /></div>
              <div style={{ marginBottom: '0.75rem' }}><Label>Title Line 1</Label><Input value={config.titleLine1} onChange={v => updateField('titleLine1', v)} /></div>
              <div style={{ marginBottom: '0.75rem' }}><Label>Title Line 2</Label><Input value={config.titleLine2} onChange={v => updateField('titleLine2', v)} /></div>
              <div style={{ marginBottom: '0.75rem' }}><Label>Title Line 3</Label><Input value={config.titleLine3} onChange={v => updateField('titleLine3', v)} /></div>
              <div style={{ marginBottom: '0.75rem' }}><Label>Company</Label><Input value={config.company} onChange={v => updateField('company', v)} /></div>

              {/* Contact */}
              <div style={{
                margin: '1.25rem 0',
                paddingTop: '1.25rem',
                borderTop: '1px solid rgba(6,29,55,0.06)',
              }}>
                <Eyebrow style={{ marginBottom: '0.75rem', fontSize: '7px' }}>Contact Details</Eyebrow>
                <div style={{ marginBottom: '0.6rem' }}><Label>Phone</Label><Input value={config.phone} onChange={v => updateField('phone', v)} /></div>
                <div style={{ marginBottom: '0.6rem' }}><Label>Mobile</Label><Input value={config.mobile} onChange={v => updateField('mobile', v)} /></div>
                <div style={{ marginBottom: '0.6rem' }}><Label>Email</Label><Input value={config.email} onChange={v => updateField('email', v)} /></div>
                <div style={{ marginBottom: '0.6rem' }}><Label>Website</Label><Input value={config.website} onChange={v => updateField('website', v)} /></div>
              </div>

              {/* Address */}
              <div style={{ marginBottom: '0.6rem' }}><Label>Address</Label><Input value={config.address} onChange={v => updateField('address', v)} /></div>
              <div style={{ marginBottom: '0.6rem' }}><Label>Postcode &amp; City</Label><Input value={config.postcodeCity} onChange={v => updateField('postcodeCity', v)} /></div>
              <div style={{ marginBottom: '0.6rem' }}><Label>Country</Label><Input value={config.country} onChange={v => updateField('country', v)} /></div>
              <div style={{ marginBottom: '0.6rem' }}><Label>CVR Number</Label><Input value={config.cvr} onChange={v => updateField('cvr', v)} /></div>

              {/* Social */}
              <div style={{
                margin: '1.25rem 0',
                paddingTop: '1.25rem',
                borderTop: '1px solid rgba(6,29,55,0.06)',
              }}>
                <Eyebrow style={{ marginBottom: '0.75rem', fontSize: '7px' }}>Social Links</Eyebrow>
                <div style={{ marginBottom: '0.6rem' }}><Label>LinkedIn</Label><Input value={config.linkedin} onChange={v => updateField('linkedin', v)} /></div>
                <div style={{ marginBottom: '0.6rem' }}><Label>Facebook</Label><Input value={config.facebook} onChange={v => updateField('facebook', v)} /></div>
                <div style={{ marginBottom: '0.6rem' }}><Label>Instagram</Label><Input value={config.instagram} onChange={v => updateField('instagram', v)} /></div>
              </div>

              {/* Options */}
              <div style={{
                paddingTop: '1rem',
                borderTop: '1px solid rgba(6,29,55,0.06)',
              }}>
                <Toggle checked={config.showEmblem} onChange={v => updateField('showEmblem', v)} label="Show emblem" />
                <Toggle checked={config.showSocial} onChange={v => updateField('showSocial', v)} label="Show social icons" />
              </div>
            </div>
          </div>
        </div>

        {/* ===== RIGHT: PREVIEW PANEL ===== */}
        <div>
          {/* Version tabs */}
          <div style={{
            display: 'flex',
            gap: '2px',
            marginBottom: '1.5rem',
            background: 'rgba(6,29,55,0.04)',
            padding: '3px',
            borderRadius: '3px',
          }}>
            {versions.map(v => (
              <button
                key={v.key}
                onClick={() => setVersion(v.key)}
                style={{
                  flex: 1,
                  padding: '10px 8px',
                  fontFamily: "'Jost', sans-serif",
                  fontWeight: version === v.key ? 500 : 400,
                  fontSize: '9.5px',
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                  border: 'none',
                  background: version === v.key ? '#fff' : 'transparent',
                  color: version === v.key ? '#061D37' : '#8C949E',
                  cursor: 'pointer',
                  borderRadius: '2px',
                  boxShadow: version === v.key ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
                  transition: 'all 0.15s',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '6px',
                }}
              >
                {v.key === 'luxury' && <img src="/logo/emblem/emblem_32.png" alt="" style={{ width: '14px', height: 'auto', opacity: version === v.key ? 0.8 : 0.4 }} />}
                {v.key === 'modern' && <img src="/logo/horizontal/horizontal_120.png" alt="" style={{ width: '20px', height: 'auto', opacity: version === v.key ? 0.8 : 0.4 }} />}
                {v.key === 'minimal' && <img src="/logo/emblem/emblem_32.png" alt="" style={{ width: '12px', height: 'auto', opacity: version === v.key ? 0.6 : 0.3 }} />}
                {v.key === 'luxury' ? 'A — Luxury' : v.key === 'modern' ? 'B — Modern' : 'C — Minimal'}
              </button>
            ))}
          </div>

          {/* Preview Card */}
          <div style={{
            background: mode === 'dark' ? '#04152A' : '#fff',
            border: mode === 'dark' ? '1px solid rgba(196,160,95,0.12)' : '1px solid rgba(6,29,55,0.06)',
            overflow: 'hidden',
            marginBottom: '1.5rem',
          }}>
            {/* Preview header */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '0.6rem 1.25rem',
              borderBottom: mode === 'dark' ? '1px solid rgba(196,160,95,0.08)' : '1px solid rgba(6,29,55,0.06)',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <img src="/logo/emblem/emblem_32.png" alt="" style={{
                  width: '16px',
                  height: 'auto',
                  opacity: mode === 'dark' ? 0.6 : 0.5,
                  filter: mode === 'dark' ? 'brightness(1.5)' : 'none',
                }} />
                <span style={{
                  fontFamily: "'Jost', sans-serif",
                  fontWeight: 500,
                  fontSize: '8.5px',
                  letterSpacing: '0.2em',
                  textTransform: 'uppercase',
                  color: mode === 'dark' ? '#C4A05F' : '#8C6A2D',
                }}>
                  Live Preview &middot; {mode === 'light' ? 'Light Mode' : 'Dark Mode'}
                </span>
              </div>
              <span style={{
                fontFamily: "'Jost', sans-serif",
                fontSize: '8px',
                letterSpacing: '0.12em',
                color: mode === 'dark' ? '#5A6B7D' : '#8C949E',
                textTransform: 'uppercase',
              }}>{versionLabel}</span>
            </div>

            {/* Live signature render */}
            <div style={{
              padding: '2.5rem',
              minHeight: '200px',
              background: mode === 'dark' ? '#04152A' : '#fff',
            }}>
              <div dangerouslySetInnerHTML={{ __html: generatedHTML }} />
            </div>
          </div>

          {/* Mobile preview */}
          <div style={{ marginBottom: '1.5rem' }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              marginBottom: '0.75rem',
            }}>
              <img src="/logo/emblem/emblem_32.png" alt="" style={{ width: '16px', height: 'auto', opacity: 0.5 }} />
              <span style={{
                fontFamily: "'Cinzel', serif",
                fontWeight: 600,
                fontSize: '12px',
                color: '#061D37',
                letterSpacing: '0.04em',
              }}>Mobile Preview</span>
              <GoldHairline style={{ flex: 1 }} />
              <span style={{
                fontFamily: "'Jost', sans-serif",
                fontSize: '8px',
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
                color: '#8C949E',
              }}>320px</span>
            </div>
            <div style={{
              background: mode === 'dark' ? '#04152A' : '#fff',
              border: mode === 'dark' ? '1px solid rgba(196,160,95,0.12)' : '1px solid rgba(6,29,55,0.06)',
              padding: '2rem',
              maxWidth: '360px',
            }}>
              <div dangerouslySetInnerHTML={{ __html: mobileHTML }} />
            </div>
          </div>

          {/* Taglines */}
          <div style={{ marginBottom: '1.5rem' }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              marginBottom: '0.75rem',
            }}>
              <img src="/logo/emblem/emblem_32.png" alt="" style={{ width: '16px', height: 'auto', opacity: 0.5 }} />
              <span style={{
                fontFamily: "'Cinzel', serif",
                fontWeight: 600,
                fontSize: '12px',
                color: '#061D37',
                letterSpacing: '0.04em',
              }}>Executive Taglines</span>
              <GoldHairline style={{ flex: 1 }} />
            </div>
            <div style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '6px',
            }}>
              {taglines.map((t, i) => (
                <button
                  key={i}
                  onClick={() => {
                    navigator.clipboard.writeText(t);
                    setCopiedTagline(i);
                    setTimeout(() => setCopiedTagline(null), 1500);
                  }}
                  title="Click to copy"
                  style={{
                    fontFamily: "'Cormorant Garamond', serif",
                    fontStyle: 'italic',
                    fontSize: '12px',
                    color: copiedTagline === i ? '#1F6B45' : '#39424E',
                    background: '#fff',
                    border: copiedTagline === i ? '1px solid rgba(31,107,69,0.3)' : '1px solid rgba(6,29,55,0.08)',
                    padding: '6px 12px',
                    cursor: 'pointer',
                    borderRadius: '2px',
                    transition: 'all 0.15s',
                  }}
                  onMouseEnter={e => {
                    e.currentTarget.style.borderColor = 'rgba(196,160,95,0.4)';
                    e.currentTarget.style.background = 'rgba(196,160,95,0.04)';
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.borderColor = 'rgba(6,29,55,0.08)';
                    e.currentTarget.style.background = '#fff';
                  }}
                >
                  {copiedTagline === i ? 'Copied' : t}
                </button>
              ))}
            </div>
          </div>

          {/* Export Button */}
          <button
            onClick={() => setShowExport(!showExport)}
            style={{
              width: '100%',
              padding: '14px',
              fontFamily: "'Jost', sans-serif",
              fontWeight: 500,
              fontSize: '10px',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: '#fff',
              background: '#061D37',
              border: 'none',
              cursor: 'pointer',
              borderRadius: '2px',
              transition: 'background 0.2s',
              marginBottom: '1.5rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '10px',
            }}
            onMouseEnter={e => e.currentTarget.style.background = '#04152A'}
            onMouseLeave={e => e.currentTarget.style.background = '#061D37'}
          >
            <img src="/logo/emblem/emblem_32.png" alt="" style={{ width: '16px', height: 'auto', opacity: 0.5, filter: 'brightness(2)' }} />
            {showExport ? 'Hide Export Panel' : 'Export Production HTML'}
          </button>

          {/* Export Panel */}
          {showExport && (
            <div ref={exportRef} style={{
              background: '#fff',
              border: '1px solid rgba(6,29,55,0.1)',
              overflow: 'hidden',
            }}>
              {/* Export header with emblem */}
              <div style={{
                background: '#061D37',
                padding: '0.6rem 1.25rem',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
              }}>
                <img src="/logo/emblem/emblem_32.png" alt="" style={{ width: '18px', height: 'auto', opacity: 0.6, filter: 'brightness(1.5)' }} />
                <span style={{
                  fontFamily: "'Jost', sans-serif",
                  fontWeight: 500,
                  fontSize: '9.5px',
                  letterSpacing: '0.2em',
                  textTransform: 'uppercase',
                  color: '#E4C77D',
                }}>Export Code</span>
              </div>

              {/* Format tabs */}
              <div style={{
                display: 'flex',
                gap: '1px',
                background: 'rgba(6,29,55,0.04)',
                padding: '3px',
              }}>
                {([
                  { key: 'html' as ExportFormat, label: 'HTML' },
                  { key: 'outlook' as ExportFormat, label: 'Outlook' },
                  { key: 'gmail' as ExportFormat, label: 'Gmail' },
                  { key: 'plaintext' as ExportFormat, label: 'Plain Text' },
                ]).map(f => (
                  <button
                    key={f.key}
                    onClick={() => setExportFormat(f.key)}
                    style={{
                      flex: 1,
                      padding: '8px',
                      fontFamily: "'Jost', sans-serif",
                      fontWeight: exportFormat === f.key ? 500 : 400,
                      fontSize: '9px',
                      letterSpacing: '0.12em',
                      textTransform: 'uppercase',
                      border: 'none',
                      background: exportFormat === f.key ? '#fff' : 'transparent',
                      color: exportFormat === f.key ? '#061D37' : '#8C949E',
                      cursor: 'pointer',
                      borderRadius: '2px',
                      boxShadow: exportFormat === f.key ? '0 1px 2px rgba(0,0,0,0.06)' : 'none',
                    }}
                  >{f.label}</button>
                ))}
              </div>

              {/* Code block */}
              <div style={{ padding: '1.25rem' }}>
                <div style={{
                  background: '#04152A',
                  padding: '1.25rem',
                  borderRadius: '2px',
                  overflow: 'hidden',
                }}>
                  <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: '0.75rem',
                  }}>
                    <span style={{
                      fontFamily: "'Jost', sans-serif",
                      fontSize: '8px',
                      letterSpacing: '0.18em',
                      textTransform: 'uppercase',
                      color: '#8C6A2D',
                    }}>
                      {exportFormat === 'html' && 'Inline CSS HTML'}
                      {exportFormat === 'outlook' && 'Outlook-Compatible HTML'}
                      {exportFormat === 'gmail' && 'Gmail-Compatible HTML'}
                      {exportFormat === 'plaintext' && 'Plain Text Fallback'}
                    </span>
                    <button
                      onClick={() => handleCopy(getExportContent())}
                      style={{
                        fontFamily: "'Jost', sans-serif",
                        fontSize: '9px',
                        fontWeight: 500,
                        letterSpacing: '0.16em',
                        textTransform: 'uppercase',
                        color: '#C4A05F',
                        background: 'transparent',
                        border: '1px solid rgba(196,160,95,0.35)',
                        padding: '4px 14px',
                        cursor: 'pointer',
                        borderRadius: '2px',
                        transition: 'all 0.15s',
                      }}
                      onMouseEnter={e => e.currentTarget.style.background = 'rgba(196,160,95,0.12)'}
                      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                    >
                      {copied ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <pre style={{
                    fontFamily: "'Courier New', monospace",
                    fontSize: '10px',
                    lineHeight: 1.65,
                    color: '#A8B4C4',
                    whiteSpace: 'pre-wrap',
                    wordBreak: 'break-all',
                    maxHeight: '400px',
                    overflowY: 'auto',
                    margin: 0,
                  }}>{getExportContent()}</pre>
                </div>
              </div>
            </div>
          )}

          {/* Footer */}
          <div style={{
            marginTop: '3rem',
            paddingTop: '1.5rem',
            borderTop: '1px solid rgba(6,29,55,0.06)',
            textAlign: 'center',
          }}>
            <img src="/logo/emblem/emblem_32.png" alt="" style={{ width: '20px', height: 'auto', opacity: 0.4, marginBottom: '0.5rem' }} />
            <div style={{ color: '#C4A05F', fontSize: '7px', letterSpacing: '0.6em', marginBottom: '0.5rem' }}>&#9670; &#9670; &#9670;</div>
            <div style={{
              fontFamily: "'Jost', sans-serif",
              fontSize: '8px',
              letterSpacing: '0.28em',
              textTransform: 'uppercase',
              color: '#8C949E',
              lineHeight: 2,
            }}>
              Omsorg &middot; Tryghed &middot; Hver Dag
            </div>
            <div style={{
              fontFamily: "'Jost', sans-serif",
              fontSize: '7.5px',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: '#A8B0B8',
            }}>
              Premium Care ApS &middot; Email Identity System v2.0
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
